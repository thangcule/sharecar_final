<?php 
namespace App\Lib;
use App\Location;

class Distance {
    const ACCEPT_DISTANCE = 5; // meter

    /**
     * @param $origin
     * @param $destination
     * @return bool
     */
    public static function checkNearBy($from_lat, $from_lng, $destination)
    {
        if (empty($destination))
            return FALSE;
        
        $distance = self::getDrivingDistance($from_lat, $from_lng, $destination);
        
        if ($distance['dist'] == 0)
            return TRUE;
        
        if ($distance['dist'] == -1 || $distance['dist'] > self::ACCEPT_DISTANCE) {
            return FALSE;
        } else return TRUE;
    }

    /**
     * @param $origin
     * @param $destination
     * @return array
     */
    public static function getDrivingDistance($from_lat, $from_lng, $destination)
    {
        $to = Location::where('address', $destination)->first();
        if (empty($to)) 
            return array(
                'dist'  => -1,
                'time'  => -1
            );
        return array(
            'dist' => self::distance($from_lat, $from_lng, $to->lat, $to->lng),
            'time' => -1,
        );
    }

    public static function distance($lat1, $lon1, $lat2, $lon2) {
      if (($lat1 == $lat2) && ($lon1 == $lon2)) {
        return 0;
      }
      else {
        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        return number_format($miles * 1.609344, 2, '.', '');
      }
    }
}





















