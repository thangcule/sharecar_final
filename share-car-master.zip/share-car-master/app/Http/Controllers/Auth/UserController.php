<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Bookmark;
use App\Ride;
use App\User;
use Auth;

class UserController extends Controller
{
	
	/**
	 * change profile : phone + name
	 * @param  Request $request 
	 * @return 
	 */
	public function profile(Request $request)
	{
		$user = User::where('id', Auth::id())->first();
		if ($request->isMethod("POST")) {
			$this->validate($request, [
				'name' => 'required|string|max:255',
				'phone' => 'required|numeric'
			]);
			$user->update($request->all());
		}
		return view('auth.profile', compact('user'));
	}
}