<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('web');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function clean()
    {
        return view('clean_code');
    }

    public function sp_01()
    {
        return view('sp/slide_01');
    }

    public function sp_02()
    {
        return view('sp/slide_02');
    }

    public function sp_03()
    {
        return view('sp/slide_03');
    }

    public function sp_04()
    {
        return view('sp/slide_04');
    }

    public function sp_05()
    {
        return view('sp/slide_05');
    }
    
    public function sp_06()
    {
        return view('sp/slide_06');
    }
    
    public function sp_07()
    {
        return view('sp/slide_07');
    }

    public function viola()
    {
        return view('viola');
    }
}
