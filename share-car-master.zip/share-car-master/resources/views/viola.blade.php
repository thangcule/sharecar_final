<html>
<head><meta http-equiv=Content-Type content="text/html; charset=UTF-8">
<style type="text/css">
<!--
span.cls_002{font-family:Times,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_002{font-family:Times,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_003{font-family:Times,serif;font-size:8.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_003{font-family:Times,serif;font-size:8.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_004{font-family:Times,serif;font-size:17.3px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_004{font-family:Times,serif;font-size:17.3px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_005{font-family:Times,serif;font-size:12.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_005{font-family:Times,serif;font-size:12.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_006{font-family:Courier New,serif;font-size:12.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_006{font-family:Courier New,serif;font-size:12.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_007{font-family:Times,serif;font-size:14.4px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_007{font-family:Times,serif;font-size:14.4px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_008{font-family:Times,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
div.cls_008{font-family:Times,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
span.cls_010{font-family:Times,serif;font-size:6.9px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_010{font-family:Times,serif;font-size:6.9px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_011{font-family:Times,serif;font-size:7.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_011{font-family:Times,serif;font-size:7.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_012{font-family:Times,serif;font-size:12.0px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_012{font-family:Times,serif;font-size:12.0px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_013{font-family:Times,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_013{font-family:Times,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_009{font-family:Times,serif;font-size:6.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_009{font-family:Times,serif;font-size:6.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_014{font-family:Times,serif;font-size:8.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_014{font-family:Times,serif;font-size:8.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_015{font-family:Times,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_015{font-family:Times,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_017{font-family:Arial,serif;font-size:7.0px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
div.cls_017{font-family:Arial,serif;font-size:7.0px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
span.cls_016{font-family:Arial,serif;font-size:10.4px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_016{font-family:Arial,serif;font-size:10.4px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_018{font-family:Times,serif;font-size:7.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_018{font-family:Times,serif;font-size:7.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_019{font-family:Times,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_019{font-family:Times,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_020{font-family:Times,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
div.cls_020{font-family:Times,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
-->
</style>
<script type="text/javascript" src="wz_jsgraphics.js"></script>
</head>
<body>
<div style="position:absolute;left:50%;margin-left:-306px;top:0px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background1.jpg" width=612 height=792></div>
<div style="position:absolute;left:127.32px;top:39.62px" class="cls_002"><span class="cls_002">A</span><span class="cls_003">CCEPTED</span><span class="cls_002"> C</span><span class="cls_003">ONFERENCE ON</span><span class="cls_002"> C</span><span class="cls_003">OMPUTER</span><span class="cls_002"> V</span><span class="cls_003">ISION AND</span><span class="cls_002"> P</span><span class="cls_003">ATTERN</span><span class="cls_002"> R</span><span class="cls_003">ECOGNITION</span><span class="cls_002"> 2001</span></div>
<div style="position:absolute;left:90.36px;top:76.16px" class="cls_004"><span class="cls_004">Rapid Object Detection using a Boosted Cascade of Simple</span></div>
<div style="position:absolute;left:274.32px;top:98.12px" class="cls_004"><span class="cls_004">Features</span></div>
<div style="position:absolute;left:168.72px;top:132.18px" class="cls_005"><span class="cls_005">Paul Viola</span></div>
<div style="position:absolute;left:401.58px;top:132.18px" class="cls_005"><span class="cls_005">Michael Jones</span></div>
<div style="position:absolute;left:143.40px;top:146.22px" class="cls_006"><span class="cls_006">viola@merl.com</span></div>
<div style="position:absolute;left:371.02px;top:146.22px" class="cls_006"><span class="cls_006">mjones@crl.dec.com</span></div>
<div style="position:absolute;left:111.48px;top:160.14px" class="cls_005"><span class="cls_005">Mitsubishi Electric Research Labs</span></div>
<div style="position:absolute;left:402.35px;top:160.14px" class="cls_005"><span class="cls_005">Compaq CRL</span></div>
<div style="position:absolute;left:139.92px;top:174.06px" class="cls_005"><span class="cls_005">201 Broadway, 8th FL</span></div>
<div style="position:absolute;left:380.45px;top:174.06px" class="cls_005"><span class="cls_005">One Cambridge Center</span></div>
<div style="position:absolute;left:138.00px;top:187.98px" class="cls_005"><span class="cls_005">Cambridge, MA 02139</span></div>
<div style="position:absolute;left:380.19px;top:187.98px" class="cls_005"><span class="cls_005">Cambridge, MA 02142</span></div>
<div style="position:absolute;left:149.88px;top:224.71px" class="cls_007"><span class="cls_007">Abstract</span></div>
<div style="position:absolute;left:317.28px;top:229.10px" class="cls_002"><span class="cls_002">tected at 15 frames per second on a conventional 700 MHz</span></div>
<div style="position:absolute;left:317.28px;top:240.98px" class="cls_002"><span class="cls_002">Intel Pentium III. In other face detection systems, auxiliary</span></div>
<div style="position:absolute;left:58.56px;top:253.46px" class="cls_008"><span class="cls_008">This paper describes a machine learning approach for vi-</span></div>
<div style="position:absolute;left:317.28px;top:252.98px" class="cls_002"><span class="cls_002">information, such as image differences in video sequences,</span></div>
<div style="position:absolute;left:58.56px;top:265.46px" class="cls_008"><span class="cls_008">sual object detection which is capable of processing images</span></div>
<div style="position:absolute;left:317.28px;top:264.98px" class="cls_002"><span class="cls_002">or pixel color in color images, have been used to achieve</span></div>
<div style="position:absolute;left:58.56px;top:277.46px" class="cls_008"><span class="cls_008">extremely rapidly and achieving high detection rates. This</span></div>
<div style="position:absolute;left:317.28px;top:276.86px" class="cls_002"><span class="cls_002">high frame rates.  Our system achieves high frame rates</span></div>
<div style="position:absolute;left:58.56px;top:289.34px" class="cls_008"><span class="cls_008">work is distinguished by three key contributions. The first</span></div>
<div style="position:absolute;left:317.28px;top:288.86px" class="cls_002"><span class="cls_002">working only with the information present in a single grey</span></div>
<div style="position:absolute;left:58.56px;top:301.34px" class="cls_008"><span class="cls_008">is the introduction of a new image representation called the</span></div>
<div style="position:absolute;left:317.28px;top:300.86px" class="cls_002"><span class="cls_002">scale image. These alternative sources of information can</span></div>
<div style="position:absolute;left:58.56px;top:313.34px" class="cls_008"><span class="cls_008">“Integral Image” which allows the features used by our de-</span></div>
<div style="position:absolute;left:317.28px;top:312.74px" class="cls_002"><span class="cls_002">also be integrated with our system to achieve even higher</span></div>
<div style="position:absolute;left:58.56px;top:325.22px" class="cls_008"><span class="cls_008">tector to be computed very quickly. The second is a learning</span></div>
<div style="position:absolute;left:317.28px;top:324.74px" class="cls_002"><span class="cls_002">frame rates.</span></div>
<div style="position:absolute;left:58.56px;top:337.22px" class="cls_008"><span class="cls_008">algorithm, based on AdaBoost, which selects a small num-</span></div>
<div style="position:absolute;left:329.16px;top:338.66px" class="cls_002"><span class="cls_002">There are three main contributions of our object detec-</span></div>
<div style="position:absolute;left:58.56px;top:349.10px" class="cls_008"><span class="cls_008">ber of critical visual features from a larger set and yields</span></div>
<div style="position:absolute;left:317.28px;top:350.66px" class="cls_002"><span class="cls_002">tion framework.  We will introduce each of these ideas</span></div>
<div style="position:absolute;left:58.56px;top:361.10px" class="cls_008"><span class="cls_008">extremely efficient classifiers[6]. The third contribution is</span></div>
<div style="position:absolute;left:317.28px;top:362.66px" class="cls_002"><span class="cls_002">briefly below and then describe them in detail in subsequent</span></div>
<div style="position:absolute;left:58.56px;top:373.10px" class="cls_008"><span class="cls_008">a method for combining increasingly more complex classi-</span></div>
<div style="position:absolute;left:317.28px;top:374.54px" class="cls_002"><span class="cls_002">sections.</span></div>
<div style="position:absolute;left:58.56px;top:384.98px" class="cls_008"><span class="cls_008">fiers in a “cascade” which allows background regions of the</span></div>
<div style="position:absolute;left:329.16px;top:388.58px" class="cls_002"><span class="cls_002">The first contribution of this paper is a new image repre-</span></div>
<div style="position:absolute;left:58.56px;top:396.98px" class="cls_008"><span class="cls_008">image to be quickly discarded while spending more compu-</span></div>
<div style="position:absolute;left:317.28px;top:400.46px" class="cls_002"><span class="cls_002">sentation called an</span><span class="cls_008"> integral image</span><span class="cls_002"> that allows for very fast</span></div>
<div style="position:absolute;left:58.56px;top:408.98px" class="cls_008"><span class="cls_008">tation on promising object-like regions. The cascade can be</span></div>
<div style="position:absolute;left:317.28px;top:412.46px" class="cls_002"><span class="cls_002">feature evaluation. Motivated in part by the work of Papa-</span></div>
<div style="position:absolute;left:58.56px;top:420.86px" class="cls_008"><span class="cls_008">viewed as an object specific focus-of-attention mechanism</span></div>
<div style="position:absolute;left:317.28px;top:424.46px" class="cls_002"><span class="cls_002">georgiou et al. our detection system does not work directly</span></div>
<div style="position:absolute;left:58.56px;top:432.86px" class="cls_008"><span class="cls_008">which unlike previous approaches provides statistical guar-</span></div>
<div style="position:absolute;left:317.28px;top:436.34px" class="cls_002"><span class="cls_002">with image intensities [10].  Like these authors we use a</span></div>
<div style="position:absolute;left:58.56px;top:444.74px" class="cls_008"><span class="cls_008">antees that discarded regions are unlikely to contain the ob-</span></div>
<div style="position:absolute;left:317.28px;top:448.34px" class="cls_002"><span class="cls_002">set of features which are reminiscent of Haar Basis func-</span></div>
<div style="position:absolute;left:58.56px;top:456.74px" class="cls_008"><span class="cls_008">ject of interest. In the domain of face detection the system</span></div>
<div style="position:absolute;left:317.28px;top:460.22px" class="cls_002"><span class="cls_002">tions (though we will also use related filters which are more</span></div>
<div style="position:absolute;left:58.56px;top:468.74px" class="cls_008"><span class="cls_008">yields detection rates comparable to the best previous sys-</span></div>
<div style="position:absolute;left:317.28px;top:472.22px" class="cls_002"><span class="cls_002">complex than Haar filters). In order to compute these fea-</span></div>
<div style="position:absolute;left:58.56px;top:480.62px" class="cls_008"><span class="cls_008">tems. Used in real-time applications, the detector runs at</span></div>
<div style="position:absolute;left:317.28px;top:484.22px" class="cls_002"><span class="cls_002">tures very rapidly at many scales we introduce the integral</span></div>
<div style="position:absolute;left:58.56px;top:492.62px" class="cls_008"><span class="cls_008">15 frames per second without resorting to image differenc-</span></div>
<div style="position:absolute;left:317.28px;top:496.10px" class="cls_002"><span class="cls_002">image representation for images. The integral image can be</span></div>
<div style="position:absolute;left:58.56px;top:504.62px" class="cls_008"><span class="cls_008">ing or skin color detection.</span></div>
<div style="position:absolute;left:317.28px;top:508.10px" class="cls_002"><span class="cls_002">computed from an image using a few operations per pixel.</span></div>
<div style="position:absolute;left:317.28px;top:520.10px" class="cls_002"><span class="cls_002">Once computed, any one of these Harr-like features can be</span></div>
<div style="position:absolute;left:317.28px;top:531.98px" class="cls_002"><span class="cls_002">computed at any scale or location in</span><span class="cls_008"> constant</span><span class="cls_002"> time.</span></div>
<div style="position:absolute;left:58.56px;top:532.15px" class="cls_007"><span class="cls_007">1. Introduction</span></div>
<div style="position:absolute;left:329.16px;top:546.02px" class="cls_002"><span class="cls_002">The second contribution of this paper is a method for</span></div>
<div style="position:absolute;left:58.56px;top:557.90px" class="cls_002"><span class="cls_002">This paper brings together new algorithms and insights to</span></div>
<div style="position:absolute;left:317.28px;top:557.90px" class="cls_002"><span class="cls_002">constructing a classifier by selecting a small number of im-</span></div>
<div style="position:absolute;left:58.56px;top:569.90px" class="cls_002"><span class="cls_002">construct a framework for robust and extremely rapid object</span></div>
<div style="position:absolute;left:317.28px;top:569.90px" class="cls_002"><span class="cls_002">portant features using AdaBoost [6]. Within any image sub-</span></div>
<div style="position:absolute;left:58.56px;top:581.90px" class="cls_002"><span class="cls_002">detection. This framework is demonstrated on, and in part</span></div>
<div style="position:absolute;left:317.28px;top:581.90px" class="cls_002"><span class="cls_002">window the total number of Harr-like features is very large,</span></div>
<div style="position:absolute;left:58.56px;top:593.78px" class="cls_002"><span class="cls_002">motivated by, the task of face detection.  Toward this end</span></div>
<div style="position:absolute;left:317.28px;top:593.78px" class="cls_002"><span class="cls_002">far larger than the number of pixels. In order to ensure fast</span></div>
<div style="position:absolute;left:58.56px;top:605.78px" class="cls_002"><span class="cls_002">we have constructed a frontal face detection system which</span></div>
<div style="position:absolute;left:317.28px;top:605.78px" class="cls_002"><span class="cls_002">classification, the learning process must exclude a large ma-</span></div>
<div style="position:absolute;left:58.56px;top:617.66px" class="cls_002"><span class="cls_002">achieves detection and false positive rates which are equiv-</span></div>
<div style="position:absolute;left:317.28px;top:617.66px" class="cls_002"><span class="cls_002">jority of the available features, and focus on a small set of</span></div>
<div style="position:absolute;left:58.56px;top:629.66px" class="cls_002"><span class="cls_002">alent to the best published results [16, 12, 15, 11, 1]. This</span></div>
<div style="position:absolute;left:317.28px;top:629.66px" class="cls_002"><span class="cls_002">critical features. Motivated by the work of Tieu and Viola,</span></div>
<div style="position:absolute;left:58.56px;top:641.66px" class="cls_002"><span class="cls_002">face detection system is most clearly distinguished from</span></div>
<div style="position:absolute;left:317.28px;top:641.66px" class="cls_002"><span class="cls_002">feature selection is achieved through a simple modification</span></div>
<div style="position:absolute;left:58.56px;top:653.54px" class="cls_002"><span class="cls_002">previous approaches in its ability to detect faces extremely</span></div>
<div style="position:absolute;left:317.28px;top:653.54px" class="cls_002"><span class="cls_002">of the AdaBoost procedure: the weak learner is constrained</span></div>
<div style="position:absolute;left:58.56px;top:665.54px" class="cls_002"><span class="cls_002">rapidly. Operating on 384 by 288 pixel images, faces are de-</span></div>
<div style="position:absolute;left:317.28px;top:665.54px" class="cls_002"><span class="cls_002">so that each weak classifier returned can depend on only a</span></div>
<div style="position:absolute;left:303.48px;top:695.42px" class="cls_002"><span class="cls_002">1</span></div>
</div>
<div style="position:absolute;left:50%;margin-left:-306px;top:802px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background2.jpg" width=612 height=792></div>
<div style="position:absolute;left:58.56px;top:7.70px" class="cls_002"><span class="cls_002">single feature [2].  As a result each stage of the boosting</span></div>
<div style="position:absolute;left:58.56px;top:19.70px" class="cls_002"><span class="cls_002">process, which selects a new weak classifier, can be viewed</span></div>
<div style="position:absolute;left:58.56px;top:31.58px" class="cls_002"><span class="cls_002">as a feature selection process. AdaBoost provides an effec-</span></div>
<div style="position:absolute;left:58.56px;top:43.58px" class="cls_002"><span class="cls_002">tive learning algorithm and strong bounds on generalization</span></div>
<div style="position:absolute;left:367.48px;top:55.01px" class="cls_010"><span class="cls_010">A</span></div>
<div style="position:absolute;left:501.43px;top:53.87px" class="cls_010"><span class="cls_010">B</span></div>
<div style="position:absolute;left:58.56px;top:55.58px" class="cls_002"><span class="cls_002">performance [13, 9, 10].</span></div>
<div style="position:absolute;left:70.44px;top:67.70px" class="cls_002"><span class="cls_002">The third major contribution of this paper is a method</span></div>
<div style="position:absolute;left:58.56px;top:79.70px" class="cls_002"><span class="cls_002">for combining successively more complex classifiers in a</span></div>
<div style="position:absolute;left:58.56px;top:91.70px" class="cls_002"><span class="cls_002">cascade structure which dramatically increases the speed of</span></div>
<div style="position:absolute;left:58.56px;top:103.58px" class="cls_002"><span class="cls_002">the detector by focusing attention on promising regions of</span></div>
<div style="position:absolute;left:58.56px;top:115.58px" class="cls_002"><span class="cls_002">the image. The notion behind focus of attention approaches</span></div>
<div style="position:absolute;left:367.48px;top:119.93px" class="cls_010"><span class="cls_010">C</span></div>
<div style="position:absolute;left:501.43px;top:118.79px" class="cls_010"><span class="cls_010">D</span></div>
<div style="position:absolute;left:58.56px;top:127.46px" class="cls_002"><span class="cls_002">is that it is often possible to rapidly determine where in an</span></div>
<div style="position:absolute;left:58.56px;top:139.46px" class="cls_002"><span class="cls_002">image an object might occur [17, 8, 1]. More complex pro-</span></div>
<div style="position:absolute;left:58.56px;top:151.46px" class="cls_002"><span class="cls_002">cessing is reserved only for these promising regions.  The</span></div>
<div style="position:absolute;left:317.28px;top:154.94px" class="cls_002"><span class="cls_002">Figure 1: Example rectangle features shown relative to the</span></div>
<div style="position:absolute;left:58.56px;top:163.34px" class="cls_002"><span class="cls_002">key measure of such an approach is the “false negative” rate</span></div>
<div style="position:absolute;left:317.28px;top:166.82px" class="cls_002"><span class="cls_002">enclosing detection window. The sum of the pixels which</span></div>
<div style="position:absolute;left:58.56px;top:175.34px" class="cls_002"><span class="cls_002">of the attentional process.  It must be the case that all, or</span></div>
<div style="position:absolute;left:317.28px;top:178.82px" class="cls_002"><span class="cls_002">lie within the white rectangles are subtracted from the sum</span></div>
<div style="position:absolute;left:58.56px;top:187.34px" class="cls_002"><span class="cls_002">almost all, object instances are selected by the attentional</span></div>
<div style="position:absolute;left:317.28px;top:190.82px" class="cls_002"><span class="cls_002">of pixels in the grey rectangles. Two-rectangle features are</span></div>
<div style="position:absolute;left:58.56px;top:199.22px" class="cls_002"><span class="cls_002">filter.</span></div>
<div style="position:absolute;left:317.28px;top:202.70px" class="cls_002"><span class="cls_002">shown in (A) and (B). Figure (C) shows a three-rectangle</span></div>
<div style="position:absolute;left:70.44px;top:211.46px" class="cls_002"><span class="cls_002">We will describe a process for training an extremely sim-</span></div>
<div style="position:absolute;left:317.28px;top:214.70px" class="cls_002"><span class="cls_002">feature, and (D) a four-rectangle feature.</span></div>
<div style="position:absolute;left:58.56px;top:223.46px" class="cls_002"><span class="cls_002">ple and efficient classifier which can be used as a “super-</span></div>
<div style="position:absolute;left:58.56px;top:235.34px" class="cls_002"><span class="cls_002">vised” focus of attention operator.  The term supervised</span></div>
<div style="position:absolute;left:58.56px;top:247.34px" class="cls_002"><span class="cls_002">refers to the fact that the attentional operator is trained to</span></div>
<div style="position:absolute;left:317.28px;top:247.46px" class="cls_002"><span class="cls_002">for using features rather than the pixels directly. The most</span></div>
<div style="position:absolute;left:58.56px;top:259.22px" class="cls_002"><span class="cls_002">detect examples of a particular class. In the domain of face</span></div>
<div style="position:absolute;left:317.28px;top:259.46px" class="cls_002"><span class="cls_002">common reason is that features can act to encode ad-hoc</span></div>
<div style="position:absolute;left:58.56px;top:271.22px" class="cls_002"><span class="cls_002">detection it is possible to achieve fewer than 1% false neg-</span></div>
<div style="position:absolute;left:317.28px;top:271.34px" class="cls_002"><span class="cls_002">domain knowledge that is difficult to learn using a finite</span></div>
<div style="position:absolute;left:58.56px;top:283.22px" class="cls_002"><span class="cls_002">atives and 40% false positives using a classifier constructed</span></div>
<div style="position:absolute;left:317.28px;top:283.34px" class="cls_002"><span class="cls_002">quantity of training data.  For this system there is also a</span></div>
<div style="position:absolute;left:58.56px;top:295.10px" class="cls_002"><span class="cls_002">from two Harr-like features.  The effect of this filter is to</span></div>
<div style="position:absolute;left:317.28px;top:295.22px" class="cls_002"><span class="cls_002">second critical motivation for features:  the feature based</span></div>
<div style="position:absolute;left:58.56px;top:307.10px" class="cls_002"><span class="cls_002">reduce by over one half the number of locations where the</span></div>
<div style="position:absolute;left:317.28px;top:307.22px" class="cls_002"><span class="cls_002">system operates much faster than a pixel-based system.</span></div>
<div style="position:absolute;left:58.56px;top:319.10px" class="cls_002"><span class="cls_002">final detector must be evaluated.</span></div>
<div style="position:absolute;left:329.16px;top:319.58px" class="cls_002"><span class="cls_002">The simple features used are reminiscent of Haar basis</span></div>
<div style="position:absolute;left:70.44px;top:331.22px" class="cls_002"><span class="cls_002">Those sub-windows which are not rejected by the initial</span></div>
<div style="position:absolute;left:317.28px;top:331.46px" class="cls_002"><span class="cls_002">functions which have been used by Papageorgiou et al. [10].</span></div>
<div style="position:absolute;left:58.56px;top:343.22px" class="cls_002"><span class="cls_002">classifier are processed by a sequence of classifiers, each</span></div>
<div style="position:absolute;left:317.28px;top:343.46px" class="cls_002"><span class="cls_002">More specifically, we use three kinds of features. The value</span></div>
<div style="position:absolute;left:58.56px;top:355.22px" class="cls_002"><span class="cls_002">slightly more complex than the last. If any classifier rejects</span></div>
<div style="position:absolute;left:317.28px;top:355.46px" class="cls_002"><span class="cls_002">of a</span><span class="cls_008"> two-rectangle feature</span><span class="cls_002"> is the difference between the sum</span></div>
<div style="position:absolute;left:58.56px;top:367.10px" class="cls_002"><span class="cls_002">the sub-window, no further processing is performed.  The</span></div>
<div style="position:absolute;left:317.28px;top:367.34px" class="cls_002"><span class="cls_002">of the pixels within two rectangular regions.  The regions</span></div>
<div style="position:absolute;left:58.56px;top:379.10px" class="cls_002"><span class="cls_002">structure of the cascaded detection process is essentially</span></div>
<div style="position:absolute;left:317.28px;top:379.34px" class="cls_002"><span class="cls_002">have the same size and shape and are horizontally or ver-</span></div>
<div style="position:absolute;left:58.56px;top:391.10px" class="cls_002"><span class="cls_002">that of a degenerate decision tree, and as such is related to</span></div>
<div style="position:absolute;left:317.28px;top:391.22px" class="cls_002"><span class="cls_002">tically adjacent (see Figure 1).  A</span><span class="cls_008"> three-rectangle feature</span></div>
<div style="position:absolute;left:58.56px;top:402.98px" class="cls_002"><span class="cls_002">the work of Geman and colleagues [1, 4].</span></div>
<div style="position:absolute;left:317.28px;top:403.22px" class="cls_002"><span class="cls_002">computes the sum within two outside rectangles subtracted</span></div>
<div style="position:absolute;left:70.44px;top:415.22px" class="cls_002"><span class="cls_002">An extremely fast face detector will have broad prac-</span></div>
<div style="position:absolute;left:317.28px;top:415.22px" class="cls_002"><span class="cls_002">from the sum in a center rectangle. Finally a</span><span class="cls_008"> four-rectangle</span></div>
<div style="position:absolute;left:58.56px;top:427.22px" class="cls_002"><span class="cls_002">tical applications.  These include user interfaces, image</span></div>
<div style="position:absolute;left:317.28px;top:427.10px" class="cls_008"><span class="cls_008">feature</span><span class="cls_002"> computes the difference between diagonal pairs of</span></div>
<div style="position:absolute;left:58.56px;top:439.10px" class="cls_002"><span class="cls_002">databases,  and teleconferencing.   In applications where</span></div>
<div style="position:absolute;left:317.28px;top:439.10px" class="cls_002"><span class="cls_002">rectangles.</span></div>
<div style="position:absolute;left:58.56px;top:451.10px" class="cls_002"><span class="cls_002">rapid frame-rates are not necessary, our system will allow</span></div>
<div style="position:absolute;left:329.16px;top:451.46px" class="cls_002"><span class="cls_002">Given that the base resolution of the detector is 24x24,</span></div>
<div style="position:absolute;left:58.56px;top:462.98px" class="cls_002"><span class="cls_002">for significant additional post-processing and analysis.  In</span></div>
<div style="position:absolute;left:317.28px;top:463.34px" class="cls_002"><span class="cls_002">the exhaustive set of rectangle features is quite large, over</span></div>
<div style="position:absolute;left:58.56px;top:474.98px" class="cls_002"><span class="cls_002">addition our system can be implemented on a wide range of</span></div>
<div style="position:absolute;left:317.28px;top:475.34px" class="cls_002"><span class="cls_002">180,000 . Note that unlike the Haar basis, the set of rectan-</span></div>
<div style="position:absolute;left:58.56px;top:486.98px" class="cls_002"><span class="cls_002">small low power devices, including hand-helds and embed-</span></div>
<div style="position:absolute;left:317.28px;top:486.61px" class="cls_002"><span class="cls_002">gle features is overcomplete</span><span class="cls_011"><sup>1</sup></span><span class="cls_002">.</span></div>
<div style="position:absolute;left:58.56px;top:498.86px" class="cls_002"><span class="cls_002">ded processors. In our lab we have implemented this face</span></div>
<div style="position:absolute;left:58.56px;top:510.86px" class="cls_002"><span class="cls_002">detector on the Compaq iPaq handheld and have achieved</span></div>
<div style="position:absolute;left:317.28px;top:512.82px" class="cls_012"><span class="cls_012">2.1. Integral Image</span></div>
<div style="position:absolute;left:58.56px;top:522.86px" class="cls_002"><span class="cls_002">detection at two frames per second (this device has a low</span></div>
<div style="position:absolute;left:317.28px;top:531.14px" class="cls_002"><span class="cls_002">Rectangle features can be computed very rapidly using an</span></div>
<div style="position:absolute;left:58.56px;top:534.74px" class="cls_002"><span class="cls_002">power 200 mips</span><span class="cls_008"> Strong Arm</span><span class="cls_002"> processor which lacks floating</span></div>
<div style="position:absolute;left:317.28px;top:543.14px" class="cls_002"><span class="cls_002">intermediate representation for the image which we call the</span></div>
<div style="position:absolute;left:58.56px;top:546.74px" class="cls_002"><span class="cls_002">point hardware).</span></div>
<div style="position:absolute;left:317.28px;top:554.41px" class="cls_002"><span class="cls_002">integral image.</span><span class="cls_011"><sup>2</sup></span><span class="cls_002"> The integral image at location</span></div>
<div style="position:absolute;left:519.73px;top:555.14px" class="cls_002"><span class="cls_002">contains</span></div>
<div style="position:absolute;left:70.44px;top:558.98px" class="cls_002"><span class="cls_002">The remainder of the paper describes our contributions</span></div>
<div style="position:absolute;left:317.28px;top:567.02px" class="cls_002"><span class="cls_002">the sum of the pixels above and to the left of</span></div>
<div style="position:absolute;left:509.38px;top:567.02px" class="cls_002"><span class="cls_002">, inclusive:</span></div>
<div style="position:absolute;left:58.56px;top:570.86px" class="cls_002"><span class="cls_002">and a number of experimental results, including a detailed</span></div>
<div style="position:absolute;left:58.56px;top:582.86px" class="cls_002"><span class="cls_002">description of our experimental methodology.  Discussion</span></div>
<div style="position:absolute;left:466.80px;top:591.10px" class="cls_013"><span class="cls_013">'</span></div>
<div style="position:absolute;left:479.70px;top:591.40px" class="cls_013"><span class="cls_013">($</span></div>
<div style="position:absolute;left:58.56px;top:594.74px" class="cls_002"><span class="cls_002">of closely related work takes place at the end of each sec-</span></div>
<div style="position:absolute;left:433.60px;top:604.20px" class="cls_013"><span class="cls_013">! #$%</span></div>
<div style="position:absolute;left:58.56px;top:606.74px" class="cls_002"><span class="cls_002">tion.</span></div>
<div style="position:absolute;left:328.08px;top:619.12px" class="cls_009"><span class="cls_009"><sup>1</sup></span><span class="cls_003">A complete basis has no linear dependence between basis elements</span></div>
<div style="position:absolute;left:317.28px;top:629.37px" class="cls_003"><span class="cls_003">and has the same number of elements as the image space, in this case 576.</span></div>
<div style="position:absolute;left:58.56px;top:629.47px" class="cls_007"><span class="cls_007">2. Features</span></div>
<div style="position:absolute;left:317.28px;top:638.85px" class="cls_003"><span class="cls_003">The full set of 180,000 thousand features is many times over-complete.</span></div>
<div style="position:absolute;left:328.08px;top:647.80px" class="cls_009"><span class="cls_009"><sup>2</sup></span><span class="cls_003">There is a close relation to “summed area tables” as used in graphics</span></div>
<div style="position:absolute;left:58.56px;top:653.54px" class="cls_002"><span class="cls_002">Our object detection procedure classifies images based on</span></div>
<div style="position:absolute;left:317.28px;top:658.05px" class="cls_003"><span class="cls_003">[3]. We choose a different name here in order to emphasize its use for the</span></div>
<div style="position:absolute;left:58.56px;top:665.54px" class="cls_002"><span class="cls_002">the value of simple features.  There are many motivations</span></div>
<div style="position:absolute;left:317.28px;top:667.53px" class="cls_003"><span class="cls_003">analysis of images, rather than for texture mapping.</span></div>
<div style="position:absolute;left:303.48px;top:695.42px" class="cls_002"><span class="cls_002">2</span></div>
</div>
<div style="position:absolute;left:50%;margin-left:-306px;top:1604px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background3.jpg" width=612 height=792></div>
<div style="position:absolute;left:317.28px;top:7.70px" class="cls_002"><span class="cls_002">could be used to learn a classification function. In our sys-</span></div>
<div style="position:absolute;left:121.84px;top:21.32px" class="cls_014"><span class="cls_014">A</span></div>
<div style="position:absolute;left:169.47px;top:21.32px" class="cls_014"><span class="cls_014">B</span></div>
<div style="position:absolute;left:317.28px;top:19.70px" class="cls_002"><span class="cls_002">tem a variant of AdaBoost is used</span><span class="cls_008"> both</span><span class="cls_002"> to select a small set</span></div>
<div style="position:absolute;left:317.28px;top:31.58px" class="cls_002"><span class="cls_002">of features</span><span class="cls_008"> and</span><span class="cls_002"> train the classifier [6]. In its original form,</span></div>
<div style="position:absolute;left:150.64px;top:38.97px" class="cls_014"><span class="cls_014">1</span></div>
<div style="position:absolute;left:202.70px;top:40.07px" class="cls_014"><span class="cls_014">2</span></div>
<div style="position:absolute;left:317.28px;top:43.58px" class="cls_002"><span class="cls_002">the AdaBoost learning algorithm is used to boost the clas-</span></div>
<div style="position:absolute;left:122.95px;top:57.72px" class="cls_014"><span class="cls_014">C</span></div>
<div style="position:absolute;left:170.58px;top:56.62px" class="cls_014"><span class="cls_014">D</span></div>
<div style="position:absolute;left:317.28px;top:55.58px" class="cls_002"><span class="cls_002">sification performance of a simple (sometimes called weak)</span></div>
<div style="position:absolute;left:150.64px;top:68.76px" class="cls_014"><span class="cls_014">3</span></div>
<div style="position:absolute;left:202.70px;top:68.76px" class="cls_014"><span class="cls_014">4</span></div>
<div style="position:absolute;left:317.28px;top:67.46px" class="cls_002"><span class="cls_002">learning algorithm. There are a number of formal guaran-</span></div>
<div style="position:absolute;left:317.28px;top:79.46px" class="cls_002"><span class="cls_002">tees provided by the AdaBoost learning procedure. Freund</span></div>
<div style="position:absolute;left:317.28px;top:91.34px" class="cls_002"><span class="cls_002">and Schapire proved that the training error of the strong</span></div>
<div style="position:absolute;left:317.28px;top:103.34px" class="cls_002"><span class="cls_002">classifier approaches zero exponentially in the number of</span></div>
<div style="position:absolute;left:317.28px;top:115.34px" class="cls_002"><span class="cls_002">rounds.  More importantly a number of results were later</span></div>
<div style="position:absolute;left:317.28px;top:127.22px" class="cls_002"><span class="cls_002">proved about generalization performance [14].  The key</span></div>
<div style="position:absolute;left:317.28px;top:139.22px" class="cls_002"><span class="cls_002">insight is that generalization performance is related to the</span></div>
<div style="position:absolute;left:58.56px;top:143.42px" class="cls_002"><span class="cls_002">Figure 2: The sum of the pixels within rectangle   can be</span></div>
<div style="position:absolute;left:317.28px;top:151.22px" class="cls_002"><span class="cls_002">margin of the examples, and that AdaBoost achieves large</span></div>
<div style="position:absolute;left:58.56px;top:155.30px" class="cls_002"><span class="cls_002">computed with four array references. The value of the inte-</span></div>
<div style="position:absolute;left:317.28px;top:163.10px" class="cls_002"><span class="cls_002">margins rapidly.</span></div>
<div style="position:absolute;left:58.56px;top:167.30px" class="cls_002"><span class="cls_002">gral image at location 1 is the sum of the pixels in rectangle</span></div>
<div style="position:absolute;left:329.16px;top:175.10px" class="cls_002"><span class="cls_002">Recall that there are over 180,000 rectangle features as-</span></div>
<div style="position:absolute;left:66.00px;top:179.30px" class="cls_002"><span class="cls_002">. The value at location 2 is</span></div>
<div style="position:absolute;left:199.80px;top:179.30px" class="cls_002"><span class="cls_002">, at location 3 is</span></div>
<div style="position:absolute;left:291.49px;top:179.30px" class="cls_002"><span class="cls_002">,</span></div>
<div style="position:absolute;left:317.28px;top:186.98px" class="cls_002"><span class="cls_002">sociated with each image sub-window, a number far larger</span></div>
<div style="position:absolute;left:58.56px;top:191.18px" class="cls_002"><span class="cls_002">and at location 4 is</span></div>
<div style="position:absolute;left:199.71px;top:191.18px" class="cls_002"><span class="cls_002">. The sum within   can</span></div>
<div style="position:absolute;left:317.28px;top:198.98px" class="cls_002"><span class="cls_002">than the number of pixels.  Even though each feature can</span></div>
<div style="position:absolute;left:58.56px;top:203.18px" class="cls_002"><span class="cls_002">be computed as</span></div>
<div style="position:absolute;left:317.28px;top:210.98px" class="cls_002"><span class="cls_002">be computed very efficiently, computing the complete set is</span></div>
<div style="position:absolute;left:317.28px;top:222.86px" class="cls_002"><span class="cls_002">prohibitively expensive. Our hypothesis, which is borne out</span></div>
<div style="position:absolute;left:58.56px;top:235.10px" class="cls_002"><span class="cls_002">where</span></div>
<div style="position:absolute;left:117.94px;top:235.10px" class="cls_002"><span class="cls_002">is the integral image and</span></div>
<div style="position:absolute;left:247.93px;top:235.10px" class="cls_002"><span class="cls_002">is the origi-</span></div>
<div style="position:absolute;left:317.28px;top:234.86px" class="cls_002"><span class="cls_002">by experiment, is that a very small number of these features</span></div>
<div style="position:absolute;left:58.56px;top:246.98px" class="cls_002"><span class="cls_002">nal image. Using the following pair of recurrences:</span></div>
<div style="position:absolute;left:317.28px;top:246.86px" class="cls_002"><span class="cls_002">can be combined to form an effective classifier. The main</span></div>
<div style="position:absolute;left:317.28px;top:258.74px" class="cls_002"><span class="cls_002">challenge is to find these features.</span></div>
<div style="position:absolute;left:283.08px;top:268.34px" class="cls_002"><span class="cls_002">(1)</span></div>
<div style="position:absolute;left:329.16px;top:270.74px" class="cls_002"><span class="cls_002">In support of this goal, the weak learning algorithm is</span></div>
<div style="position:absolute;left:125.40px;top:283.40px" class="cls_013"><span class="cls_013">(</span></div>
<div style="position:absolute;left:240.00px;top:283.40px" class="cls_013"><span class="cls_013">(</span></div>
<div style="position:absolute;left:283.08px;top:283.34px" class="cls_002"><span class="cls_002">(2)</span></div>
<div style="position:absolute;left:317.28px;top:282.62px" class="cls_002"><span class="cls_002">designed to select the single rectangle feature which best</span></div>
<div style="position:absolute;left:317.28px;top:294.62px" class="cls_002"><span class="cls_002">separates the positive and negative examples (this is similar</span></div>
<div style="position:absolute;left:108.30px;top:304.60px" class="cls_013"><span class="cls_013">(</span></div>
<div style="position:absolute;left:58.56px;top:304.58px" class="cls_002"><span class="cls_002">(where</span></div>
<div style="position:absolute;left:120.66px;top:304.58px" class="cls_002"><span class="cls_002">is the cumulative row sum,</span></div>
<div style="position:absolute;left:291.66px;top:304.58px" class="cls_002"><span class="cls_002">,</span></div>
<div style="position:absolute;left:317.28px;top:306.62px" class="cls_002"><span class="cls_002">to the approach of [2] in the domain of image database re-</span></div>
<div style="position:absolute;left:58.56px;top:316.58px" class="cls_002"><span class="cls_002">and</span></div>
<div style="position:absolute;left:133.07px;top:316.58px" class="cls_002"><span class="cls_002">) the integral image can be computed in</span></div>
<div style="position:absolute;left:317.28px;top:318.50px" class="cls_002"><span class="cls_002">trieval). For each feature, the weak learner determines the</span></div>
<div style="position:absolute;left:58.56px;top:328.58px" class="cls_002"><span class="cls_002">one pass over the original image.</span></div>
<div style="position:absolute;left:317.28px;top:330.50px" class="cls_002"><span class="cls_002">optimal threshold classification function, such that the min-</span></div>
<div style="position:absolute;left:70.44px;top:340.46px" class="cls_002"><span class="cls_002">Using the integral image any rectangular sum can be</span></div>
<div style="position:absolute;left:317.28px;top:342.50px" class="cls_002"><span class="cls_002">imum number of examples are misclassified. A weak clas-</span></div>
<div style="position:absolute;left:353.70px;top:353.90px" class="cls_013"><span class="cls_013">%</span></div>
<div style="position:absolute;left:58.56px;top:352.46px" class="cls_002"><span class="cls_002">computed in four array references (see Figure 2). Clearly</span></div>
<div style="position:absolute;left:317.28px;top:354.38px" class="cls_002"><span class="cls_002">sifier</span></div>
<div style="position:absolute;left:365.64px;top:354.38px" class="cls_002"><span class="cls_002">thus consists of a feature</span></div>
<div style="position:absolute;left:476.04px;top:354.38px" class="cls_002"><span class="cls_002">, a threshold</span></div>
<div style="position:absolute;left:539.16px;top:354.38px" class="cls_002"><span class="cls_002">and</span></div>
<div style="position:absolute;left:58.56px;top:364.46px" class="cls_002"><span class="cls_002">the difference between two rectangular sums can be com-</span></div>
<div style="position:absolute;left:317.28px;top:366.38px" class="cls_002"><span class="cls_002">a parity</span><span class="cls_013"> !</span><span class="cls_002">  indicating the direction of the inequality sign:</span></div>
<div style="position:absolute;left:58.56px;top:376.34px" class="cls_002"><span class="cls_002">puted in eight references. Since the two-rectangle features</span></div>
<div style="position:absolute;left:459.40px;top:386.60px" class="cls_013"><span class="cls_013">%%</span></div>
<div style="position:absolute;left:58.56px;top:388.34px" class="cls_002"><span class="cls_002">defined above involve adjacent rectangular sums they can</span></div>
<div style="position:absolute;left:378.40px;top:388.50px" class="cls_013"><span class="cls_013">%  #</span></div>
<div style="position:absolute;left:428.52px;top:388.22px" class="cls_002"><span class="cls_002">if</span></div>
<div style="position:absolute;left:58.56px;top:400.22px" class="cls_002"><span class="cls_002">be computed in six array references, eight in the case of</span></div>
<div style="position:absolute;left:428.52px;top:400.10px" class="cls_002"><span class="cls_002">otherwise</span></div>
<div style="position:absolute;left:58.56px;top:412.22px" class="cls_002"><span class="cls_002">the three-rectangle features, and nine for four-rectangle fea-</span></div>
<div style="position:absolute;left:317.28px;top:421.10px" class="cls_002"><span class="cls_002">Here   is a 24x24 pixel sub-window of an image. See Ta-</span></div>
<div style="position:absolute;left:58.56px;top:424.22px" class="cls_002"><span class="cls_002">tures.</span></div>
<div style="position:absolute;left:317.28px;top:433.10px" class="cls_002"><span class="cls_002">ble 1 for a summary of the boosting process.</span></div>
<div style="position:absolute;left:329.16px;top:445.10px" class="cls_002"><span class="cls_002">In practice no single feature can perform the classifica-</span></div>
<div style="position:absolute;left:58.56px;top:447.66px" class="cls_012"><span class="cls_012">2.2. Feature Discussion</span></div>
<div style="position:absolute;left:317.28px;top:456.98px" class="cls_002"><span class="cls_002">tion task with low error. Features which are selected in early</span></div>
<div style="position:absolute;left:58.56px;top:465.26px" class="cls_002"><span class="cls_002">Rectangle features are somewhat primitive when compared</span></div>
<div style="position:absolute;left:317.28px;top:468.98px" class="cls_002"><span class="cls_002">rounds of the boosting process had error rates between 0.1</span></div>
<div style="position:absolute;left:58.56px;top:477.26px" class="cls_002"><span class="cls_002">with alternatives such as steerable filters [5, 7]. Steerable fil-</span></div>
<div style="position:absolute;left:317.28px;top:480.86px" class="cls_002"><span class="cls_002">and 0.3.  Features selected in later rounds, as the task be-</span></div>
<div style="position:absolute;left:58.56px;top:489.26px" class="cls_002"><span class="cls_002">ters, and their relatives, are excellent for the detailed analy-</span></div>
<div style="position:absolute;left:317.28px;top:492.86px" class="cls_002"><span class="cls_002">comes more difficult, yield error rates between 0.4 and 0.5.</span></div>
<div style="position:absolute;left:58.56px;top:501.14px" class="cls_002"><span class="cls_002">sis of boundaries, image compression, and texture analysis.</span></div>
<div style="position:absolute;left:58.56px;top:513.14px" class="cls_002"><span class="cls_002">In contrast rectangle features, while sensitive to the pres-</span></div>
<div style="position:absolute;left:317.28px;top:516.30px" class="cls_012"><span class="cls_012">3.1. Learning Discussion</span></div>
<div style="position:absolute;left:58.56px;top:525.02px" class="cls_002"><span class="cls_002">ence of edges, bars, and other simple image structure, are</span></div>
<div style="position:absolute;left:317.28px;top:534.02px" class="cls_002"><span class="cls_002">Many general feature selection procedures have been pro-</span></div>
<div style="position:absolute;left:58.56px;top:537.02px" class="cls_002"><span class="cls_002">quite coarse.  Unlike steerable filters the only orientations</span></div>
<div style="position:absolute;left:317.28px;top:546.02px" class="cls_002"><span class="cls_002">posed (see chapter 8 of [18] for a review). Our final appli-</span></div>
<div style="position:absolute;left:58.56px;top:549.02px" class="cls_002"><span class="cls_002">available are vertical, horizontal, and diagonal. The set of</span></div>
<div style="position:absolute;left:317.28px;top:557.90px" class="cls_002"><span class="cls_002">cation demanded a very aggressive approach which would</span></div>
<div style="position:absolute;left:58.56px;top:560.90px" class="cls_002"><span class="cls_002">rectangle features do however provide a rich image repre-</span></div>
<div style="position:absolute;left:317.28px;top:569.90px" class="cls_002"><span class="cls_002">discard the vast majority of features. For a similar recogni-</span></div>
<div style="position:absolute;left:58.56px;top:572.90px" class="cls_002"><span class="cls_002">sentation which supports effective learning. In conjunction</span></div>
<div style="position:absolute;left:317.28px;top:581.90px" class="cls_002"><span class="cls_002">tion problem Papageorgiou et al. proposed a scheme for fea-</span></div>
<div style="position:absolute;left:58.56px;top:584.90px" class="cls_002"><span class="cls_002">with the integral image , the efficiency of the rectangle fea-</span></div>
<div style="position:absolute;left:317.28px;top:593.78px" class="cls_002"><span class="cls_002">ture selection based on feature variance [10]. They demon-</span></div>
<div style="position:absolute;left:58.56px;top:596.78px" class="cls_002"><span class="cls_002">ture set provides ample compensation for their limited flex-</span></div>
<div style="position:absolute;left:317.28px;top:605.78px" class="cls_002"><span class="cls_002">strated good results selecting 37 features out of a total 1734</span></div>
<div style="position:absolute;left:58.56px;top:608.78px" class="cls_002"><span class="cls_002">ibility.</span></div>
<div style="position:absolute;left:317.28px;top:617.66px" class="cls_002"><span class="cls_002">features.</span></div>
<div style="position:absolute;left:329.16px;top:629.66px" class="cls_002"><span class="cls_002">Roth et al.  propose a feature selection process based</span></div>
<div style="position:absolute;left:58.56px;top:629.95px" class="cls_007"><span class="cls_007">3. Learning Classification Functions</span></div>
<div style="position:absolute;left:317.28px;top:641.66px" class="cls_002"><span class="cls_002">on the Winnow exponential perceptron learning rule [11].</span></div>
<div style="position:absolute;left:58.56px;top:653.54px" class="cls_002"><span class="cls_002">Given a feature set and a training set of positive and neg-</span></div>
<div style="position:absolute;left:317.28px;top:653.54px" class="cls_002"><span class="cls_002">The Winnow learning process converges to a solution where</span></div>
<div style="position:absolute;left:58.56px;top:665.54px" class="cls_002"><span class="cls_002">ative images, any number of machine learning approaches</span></div>
<div style="position:absolute;left:317.28px;top:665.54px" class="cls_002"><span class="cls_002">many of these weights are zero. Nevertheless a very large</span></div>
<div style="position:absolute;left:303.48px;top:695.42px" class="cls_002"><span class="cls_002">3</span></div>
</div>
<div style="position:absolute;left:50%;margin-left:-306px;top:2406px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background4.jpg" width=612 height=792></div>
<div style="position:absolute;left:84.36px;top:8.81px" class="cls_015"><span class="cls_015">Given example images</span></div>
<div style="position:absolute;left:258.48px;top:8.81px" class="cls_015"><span class="cls_015">where</span></div>
<div style="position:absolute;left:123.96px;top:19.85px" class="cls_015"><span class="cls_015">for negative and positive examples respec-</span></div>
<div style="position:absolute;left:84.36px;top:30.77px" class="cls_015"><span class="cls_015">tively.</span></div>
<div style="position:absolute;left:161.70px;top:41.70px" class="cls_013"><span class="cls_013">!</span></div>
<div style="position:absolute;left:222.90px;top:37.90px" class="cls_013"><span class="cls_013">!&</span></div>
<div style="position:absolute;left:84.36px;top:44.40px" class="cls_015"><span class="cls_015">Initialize weights</span></div>
<div style="position:absolute;left:179.20px;top:50.20px" class="cls_013"><span class="cls_013">$</span></div>
<div style="position:absolute;left:195.90px;top:45.65px" class="cls_013"><span class="cls_013">$</span><span class="cls_015"> for</span></div>
<div style="position:absolute;left:254.52px;top:45.65px" class="cls_015"><span class="cls_015">respec-</span></div>
<div style="position:absolute;left:84.36px;top:56.69px" class="cls_015"><span class="cls_015">tively, where</span></div>
<div style="position:absolute;left:143.81px;top:56.69px" class="cls_015"><span class="cls_015">and  are the number of negatives and</span></div>
<div style="position:absolute;left:84.36px;top:67.61px" class="cls_015"><span class="cls_015">positives respectively.</span></div>
<div style="position:absolute;left:105.10px;top:74.80px" class="cls_013"><span class="cls_013">*+</span></div>
<div style="position:absolute;left:136.20px;top:81.50px" class="cls_013"><span class="cls_013">-</span></div>
<div style="position:absolute;left:84.36px;top:82.61px" class="cls_015"><span class="cls_015">For</span></div>
<div style="position:absolute;left:146.25px;top:82.61px" class="cls_015"><span class="cls_015">:</span></div>
<div style="position:absolute;left:94.56px;top:101.45px" class="cls_015"><span class="cls_015">1.  Normalize the weights,</span></div>
<div style="position:absolute;left:169.50px;top:118.90px" class="cls_013"><span class="cls_013">1</span></div>
<div style="position:absolute;left:157.60px;top:124.80px" class="cls_013"><span class="cls_013">/</span></div>
<div style="position:absolute;left:106.20px;top:148.13px" class="cls_015"><span class="cls_015">so that</span><span class="cls_013"> 5</span></div>
<div style="position:absolute;left:144.36px;top:148.13px" class="cls_015"><span class="cls_015">is a probability distribution.</span></div>
<div style="position:absolute;left:94.56px;top:163.01px" class="cls_015"><span class="cls_015">2.  For each feature,</span></div>
<div style="position:absolute;left:177.10px;top:163.01px" class="cls_015"><span class="cls_015">, train a classifier</span></div>
<div style="position:absolute;left:258.48px;top:163.01px" class="cls_015"><span class="cls_015">which</span></div>
<div style="position:absolute;left:317.28px;top:165.38px" class="cls_002"><span class="cls_002">Figure 3:  The first and second features selected by Ad-</span></div>
<div style="position:absolute;left:106.20px;top:174.05px" class="cls_015"><span class="cls_015">is restricted  to  using  a  single  feature.   The</span></div>
<div style="position:absolute;left:317.28px;top:177.38px" class="cls_002"><span class="cls_002">aBoost. The two features are shown in the top row and then</span></div>
<div style="position:absolute;left:106.20px;top:184.97px" class="cls_015"><span class="cls_015">error is evaluated with respect to</span></div>
<div style="position:absolute;left:241.00px;top:184.97px" class="cls_013"><span class="cls_013">8</span><span class="cls_015"> ,</span></div>
<div style="position:absolute;left:156.00px;top:189.50px" class="cls_013"><span class="cls_013">&lt;=</span></div>
<div style="position:absolute;left:317.28px;top:189.26px" class="cls_002"><span class="cls_002">overlayed on a typical training face in the bottom row. The</span></div>
<div style="position:absolute;left:317.28px;top:201.26px" class="cls_002"><span class="cls_002">first feature measures the difference in intensity between the</span></div>
<div style="position:absolute;left:94.56px;top:210.89px" class="cls_015"><span class="cls_015">3.  Choose the classifier,</span></div>
<div style="position:absolute;left:192.12px;top:210.89px" class="cls_015"><span class="cls_015">, with the lowest error</span></div>
<div style="position:absolute;left:317.28px;top:213.26px" class="cls_002"><span class="cls_002">region of the eyes and a region across the upper cheeks. The</span></div>
<div style="position:absolute;left:94.56px;top:225.89px" class="cls_015"><span class="cls_015">4.  Update the weights:</span></div>
<div style="position:absolute;left:317.28px;top:225.14px" class="cls_002"><span class="cls_002">feature capitalizes on the observation that the eye region is</span></div>
<div style="position:absolute;left:223.10px;top:238.80px" class="cls_013"><span class="cls_013">$</span></div>
<div style="position:absolute;left:205.00px;top:244.50px" class="cls_013"><span class="cls_013">@</span></div>
<div style="position:absolute;left:317.28px;top:237.14px" class="cls_002"><span class="cls_002">often darker than the cheeks. The second feature compares</span></div>
<div style="position:absolute;left:317.28px;top:249.02px" class="cls_002"><span class="cls_002">the intensities in the eye regions to the intensity across the</span></div>
<div style="position:absolute;left:317.28px;top:261.02px" class="cls_002"><span class="cls_002">bridge of the nose.</span></div>
<div style="position:absolute;left:106.20px;top:254.60px" class="cls_015"><span class="cls_015">where</span><span class="cls_013"><sup>EF</sup></span><span class="cls_015">  if example    is classified cor-</span></div>
<div style="position:absolute;left:140.90px;top:268.00px" class="cls_013"><span class="cls_013">&</span></div>
<div style="position:absolute;left:238.70px;top:274.80px" class="cls_013"><span class="cls_013">I</span></div>
<div style="position:absolute;left:106.20px;top:275.69px" class="cls_015"><span class="cls_015">rectly,</span></div>
<div style="position:absolute;left:157.08px;top:275.69px" class="cls_015"><span class="cls_015">otherwise, and</span></div>
<div style="position:absolute;left:84.36px;top:294.53px" class="cls_015"><span class="cls_015">The final strong classifier is:</span></div>
<div style="position:absolute;left:317.28px;top:293.90px" class="cls_002"><span class="cls_002">of the nose and cheeks (see Figure 3). This feature is rel-</span></div>
<div style="position:absolute;left:140.00px;top:302.20px" class="cls_013"><span class="cls_013">MO     S  T</span></div>
<div style="position:absolute;left:317.28px;top:305.90px" class="cls_002"><span class="cls_002">atively large in comparison with the detection sub-window,</span></div>
<div style="position:absolute;left:112.00px;top:311.50px" class="cls_013"><span class="cls_013">JL</span></div>
<div style="position:absolute;left:183.90px;top:318.10px" class="cls_013"><span class="cls_013">-Q</span></div>
<div style="position:absolute;left:317.28px;top:317.78px" class="cls_002"><span class="cls_002">and should be somewhat insensitive to size and location of</span></div>
<div style="position:absolute;left:153.96px;top:325.25px" class="cls_015"><span class="cls_015">otherwise</span></div>
<div style="position:absolute;left:317.28px;top:329.78px" class="cls_002"><span class="cls_002">the face. The second feature selected relies on the property</span></div>
<div style="position:absolute;left:120.60px;top:338.20px" class="cls_013"><span class="cls_013">OW+</span></div>
<div style="position:absolute;left:317.28px;top:341.78px" class="cls_002"><span class="cls_002">that the eyes are darker than the bridge of the nose.</span></div>
<div style="position:absolute;left:84.36px;top:345.53px" class="cls_015"><span class="cls_015">where</span></div>
<div style="position:absolute;left:58.56px;top:369.86px" class="cls_002"><span class="cls_002">Table</span></div>
<div style="position:absolute;left:85.80px;top:369.86px" class="cls_002"><span class="cls_002">1:  The AdaBoost  algorithm for classifier learn-</span></div>
<div style="position:absolute;left:317.28px;top:365.23px" class="cls_007"><span class="cls_007">4. The Attentional Cascade</span></div>
<div style="position:absolute;left:58.56px;top:381.86px" class="cls_002"><span class="cls_002">ing.  Each round of boosting selects one feature from the</span></div>
<div style="position:absolute;left:317.28px;top:389.78px" class="cls_002"><span class="cls_002">This section describes an algorithm for constructing a cas-</span></div>
<div style="position:absolute;left:58.56px;top:393.86px" class="cls_002"><span class="cls_002">180,000 potential features.</span></div>
<div style="position:absolute;left:317.28px;top:401.66px" class="cls_002"><span class="cls_002">cade of classifiers which achieves increased detection per-</span></div>
<div style="position:absolute;left:317.28px;top:413.66px" class="cls_002"><span class="cls_002">formance while radically reducing computation time. The</span></div>
<div style="position:absolute;left:58.56px;top:427.22px" class="cls_002"><span class="cls_002">number of features are retained (perhaps a few hundred or</span></div>
<div style="position:absolute;left:317.28px;top:425.66px" class="cls_002"><span class="cls_002">key insight is that smaller, and therefore more efficient,</span></div>
<div style="position:absolute;left:58.56px;top:439.22px" class="cls_002"><span class="cls_002">thousand).</span></div>
<div style="position:absolute;left:317.28px;top:437.54px" class="cls_002"><span class="cls_002">boosted classifiers can be constructed which reject many of</span></div>
<div style="position:absolute;left:317.28px;top:449.54px" class="cls_002"><span class="cls_002">the negative sub-windows while detecting almost all posi-</span></div>
<div style="position:absolute;left:317.28px;top:461.42px" class="cls_002"><span class="cls_002">tive instances (i.e. the threshold of a boosted classifier can</span></div>
<div style="position:absolute;left:58.56px;top:466.50px" class="cls_012"><span class="cls_012">3.2. Learning Results</span></div>
<div style="position:absolute;left:317.28px;top:473.42px" class="cls_002"><span class="cls_002">be adjusted so that the false negative rate is close to zero).</span></div>
<div style="position:absolute;left:58.56px;top:485.54px" class="cls_002"><span class="cls_002">While details on the training and performance of the final</span></div>
<div style="position:absolute;left:317.28px;top:485.42px" class="cls_002"><span class="cls_002">Simpler classifiers are used to reject the majority of sub-</span></div>
<div style="position:absolute;left:58.56px;top:497.42px" class="cls_002"><span class="cls_002">system are presented in Section 5, several simple results</span></div>
<div style="position:absolute;left:317.28px;top:497.30px" class="cls_002"><span class="cls_002">windows before more complex classifiers are called upon</span></div>
<div style="position:absolute;left:58.56px;top:509.42px" class="cls_002"><span class="cls_002">merit discussion.  Initial experiments demonstrated that a</span></div>
<div style="position:absolute;left:317.28px;top:509.30px" class="cls_002"><span class="cls_002">to achieve low false positive rates.</span></div>
<div style="position:absolute;left:58.56px;top:521.42px" class="cls_002"><span class="cls_002">frontal face classifier constructed from 200 features yields</span></div>
<div style="position:absolute;left:329.16px;top:521.66px" class="cls_002"><span class="cls_002">The overall form of the detection process is that of a de-</span></div>
<div style="position:absolute;left:58.56px;top:533.30px" class="cls_002"><span class="cls_002">a detection rate of 95% with a false positive rate of 1 in</span></div>
<div style="position:absolute;left:317.28px;top:533.66px" class="cls_002"><span class="cls_002">generate decision tree, what we call a “cascade” (see Fig-</span></div>
<div style="position:absolute;left:58.56px;top:545.30px" class="cls_002"><span class="cls_002">14084. These results are compelling, but not sufficient for</span></div>
<div style="position:absolute;left:317.28px;top:545.54px" class="cls_002"><span class="cls_002">ure 4). A positive result from the first classifier triggers the</span></div>
<div style="position:absolute;left:58.56px;top:557.30px" class="cls_002"><span class="cls_002">many real-world tasks. In terms of computation, this clas-</span></div>
<div style="position:absolute;left:317.28px;top:557.54px" class="cls_002"><span class="cls_002">evaluation of a second classifier which has also been ad-</span></div>
<div style="position:absolute;left:58.56px;top:569.18px" class="cls_002"><span class="cls_002">sifier is probably faster than any other published system,</span></div>
<div style="position:absolute;left:317.28px;top:569.54px" class="cls_002"><span class="cls_002">justed to achieve very high detection rates. A positive result</span></div>
<div style="position:absolute;left:58.56px;top:581.18px" class="cls_002"><span class="cls_002">requiring 0.7 seconds to scan an 384 by 288 pixel image.</span></div>
<div style="position:absolute;left:317.28px;top:581.42px" class="cls_002"><span class="cls_002">from the second classifier triggers a third classifier, and so</span></div>
<div style="position:absolute;left:58.56px;top:593.06px" class="cls_002"><span class="cls_002">Unfortunately, the most straightforward technique for im-</span></div>
<div style="position:absolute;left:317.28px;top:593.42px" class="cls_002"><span class="cls_002">on. A negative outcome at any point leads to the immediate</span></div>
<div style="position:absolute;left:58.56px;top:605.06px" class="cls_002"><span class="cls_002">proving detection performance, adding features to the clas-</span></div>
<div style="position:absolute;left:317.28px;top:605.30px" class="cls_002"><span class="cls_002">rejection of the sub-window.</span></div>
<div style="position:absolute;left:58.56px;top:617.06px" class="cls_002"><span class="cls_002">sifier, directly increases computation time.</span></div>
<div style="position:absolute;left:329.16px;top:617.66px" class="cls_002"><span class="cls_002">Stages in the cascade are constructed by training clas-</span></div>
<div style="position:absolute;left:70.44px;top:629.66px" class="cls_002"><span class="cls_002">For the task of face detection, the initial rectangle fea-</span></div>
<div style="position:absolute;left:317.28px;top:629.66px" class="cls_002"><span class="cls_002">sifiers using AdaBoost and then adjusting the threshold to</span></div>
<div style="position:absolute;left:58.56px;top:641.66px" class="cls_002"><span class="cls_002">tures selected by AdaBoost are meaningful and easily inter-</span></div>
<div style="position:absolute;left:317.28px;top:641.66px" class="cls_002"><span class="cls_002">minimize false negatives.  Note that the default AdaBoost</span></div>
<div style="position:absolute;left:58.56px;top:653.54px" class="cls_002"><span class="cls_002">preted. The first feature selected seems to focus on the prop-</span></div>
<div style="position:absolute;left:317.28px;top:653.54px" class="cls_002"><span class="cls_002">threshold is designed to yield a low error rate on the train-</span></div>
<div style="position:absolute;left:58.56px;top:665.54px" class="cls_002"><span class="cls_002">erty that the region of the eyes is often darker than the region</span></div>
<div style="position:absolute;left:317.28px;top:665.54px" class="cls_002"><span class="cls_002">ing data. In general a lower threshold yields higher detec-</span></div>
<div style="position:absolute;left:303.48px;top:695.42px" class="cls_002"><span class="cls_002">4</span></div>
</div>
<div style="position:absolute;left:50%;margin-left:-306px;top:3208px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background5.jpg" width=612 height=792></div>
<div style="position:absolute;left:317.28px;top:5.70px" class="cls_012"><span class="cls_012">4.1. Training a Cascade of Classifiers</span></div>
<div style="position:absolute;left:93.91px;top:15.48px" class="cls_017"><span class="cls_017">All Sub−windows</span></div>
<div style="position:absolute;left:317.28px;top:23.90px" class="cls_002"><span class="cls_002">The cascade training process involves two types of trade-</span></div>
<div style="position:absolute;left:317.28px;top:35.90px" class="cls_002"><span class="cls_002">offs.   In most cases classifiers with more features will</span></div>
<div style="position:absolute;left:135.64px;top:43.63px" class="cls_016"><span class="cls_016">T</span></div>
<div style="position:absolute;left:171.60px;top:43.63px" class="cls_016"><span class="cls_016">T</span></div>
<div style="position:absolute;left:207.57px;top:43.63px" class="cls_016"><span class="cls_016">T</span></div>
<div style="position:absolute;left:229.15px;top:48.52px" class="cls_017"><span class="cls_017">Further</span></div>
<div style="position:absolute;left:317.28px;top:47.78px" class="cls_002"><span class="cls_002">achieve higher detection rates and lower false positive rates.</span></div>
<div style="position:absolute;left:121.25px;top:54.26px" class="cls_018"><span class="cls_018">1</span></div>
<div style="position:absolute;left:157.22px;top:54.26px" class="cls_018"><span class="cls_018">2</span></div>
<div style="position:absolute;left:193.19px;top:54.26px" class="cls_018"><span class="cls_018">3</span></div>
<div style="position:absolute;left:230.59px;top:57.14px" class="cls_017"><span class="cls_017">Processing</span></div>
<div style="position:absolute;left:317.28px;top:59.78px" class="cls_002"><span class="cls_002">At the same time classifiers with more features require more</span></div>
<div style="position:absolute;left:124.13px;top:68.05px" class="cls_016"><span class="cls_016">F</span></div>
<div style="position:absolute;left:160.10px;top:68.05px" class="cls_016"><span class="cls_016">F</span></div>
<div style="position:absolute;left:196.06px;top:68.05px" class="cls_016"><span class="cls_016">F</span></div>
<div style="position:absolute;left:317.28px;top:71.78px" class="cls_002"><span class="cls_002">time to compute. In principle one could define an optimiza-</span></div>
<div style="position:absolute;left:317.28px;top:83.66px" class="cls_002"><span class="cls_002">tion framework in which: i) the number of classifier stages,</span></div>
<div style="position:absolute;left:150.02px;top:98.79px" class="cls_017"><span class="cls_017">Reject Sub−window</span></div>
<div style="position:absolute;left:317.28px;top:95.66px" class="cls_002"><span class="cls_002">ii) the number of features in each stage, and iii) the thresh-</span></div>
<div style="position:absolute;left:317.28px;top:107.66px" class="cls_002"><span class="cls_002">old of each stage, are traded off in order to minimize the</span></div>
<div style="position:absolute;left:317.28px;top:119.54px" class="cls_002"><span class="cls_002">expected number of evaluated features. Unfortunately find-</span></div>
<div style="position:absolute;left:317.28px;top:131.54px" class="cls_002"><span class="cls_002">ing this optimum is a tremendously difficult problem.</span></div>
<div style="position:absolute;left:58.56px;top:139.46px" class="cls_002"><span class="cls_002">Figure 4: Schematic depiction of a the detection cascade.</span></div>
<div style="position:absolute;left:329.16px;top:143.78px" class="cls_002"><span class="cls_002">In practice a very simple framework is used to produce</span></div>
<div style="position:absolute;left:58.56px;top:151.34px" class="cls_002"><span class="cls_002">A series of classifiers are applied to every sub-window. The</span></div>
<div style="position:absolute;left:317.28px;top:155.66px" class="cls_002"><span class="cls_002">an effective classifier which is highly efficient. Each stage</span></div>
<div style="position:absolute;left:58.56px;top:163.34px" class="cls_002"><span class="cls_002">initial classifier eliminates a large number of negative exam-</span></div>
<div style="position:absolute;left:317.28px;top:167.66px" class="cls_002"><span class="cls_002">in the cascade reduces the false positive rate and decreases</span></div>
<div style="position:absolute;left:58.56px;top:175.34px" class="cls_002"><span class="cls_002">ples with very little processing. Subsequent layers eliminate</span></div>
<div style="position:absolute;left:317.28px;top:179.66px" class="cls_002"><span class="cls_002">the detection rate.  A target is selected for the minimum</span></div>
<div style="position:absolute;left:58.56px;top:187.22px" class="cls_002"><span class="cls_002">additional negatives but require additional computation. Af-</span></div>
<div style="position:absolute;left:317.28px;top:191.54px" class="cls_002"><span class="cls_002">reduction in false positives and the maximum decrease in</span></div>
<div style="position:absolute;left:58.56px;top:199.22px" class="cls_002"><span class="cls_002">ter several stages of processing the number of sub-windows</span></div>
<div style="position:absolute;left:317.28px;top:203.54px" class="cls_002"><span class="cls_002">detection. Each stage is trained by adding features until the</span></div>
<div style="position:absolute;left:58.56px;top:211.10px" class="cls_002"><span class="cls_002">have been reduced radically.  Further processing can take</span></div>
<div style="position:absolute;left:317.28px;top:215.42px" class="cls_002"><span class="cls_002">target detection and false positives rates are met ( these rates</span></div>
<div style="position:absolute;left:58.56px;top:223.10px" class="cls_002"><span class="cls_002">any form such as additional stages of the cascade (as in our</span></div>
<div style="position:absolute;left:317.28px;top:227.42px" class="cls_002"><span class="cls_002">are determined by testing the detector on a validation set).</span></div>
<div style="position:absolute;left:58.56px;top:235.10px" class="cls_002"><span class="cls_002">detection system) or an alternative detection system.</span></div>
<div style="position:absolute;left:317.28px;top:239.42px" class="cls_002"><span class="cls_002">Stages are added until the overall target for false positive</span></div>
<div style="position:absolute;left:317.28px;top:251.30px" class="cls_002"><span class="cls_002">and detection rate is met.</span></div>
<div style="position:absolute;left:317.28px;top:276.42px" class="cls_012"><span class="cls_012">4.2. Detector Cascade Discussion</span></div>
<div style="position:absolute;left:58.56px;top:284.66px" class="cls_002"><span class="cls_002">tion rates and higher false positive rates.</span></div>
<div style="position:absolute;left:317.28px;top:294.62px" class="cls_002"><span class="cls_002">The complete face detection cascade has 38 stages with over</span></div>
<div style="position:absolute;left:70.44px;top:305.30px" class="cls_002"><span class="cls_002">For example an excellent first stage classifier can be con-</span></div>
<div style="position:absolute;left:317.28px;top:306.50px" class="cls_002"><span class="cls_002">6000 features. Nevertheless the cascade structure results in</span></div>
<div style="position:absolute;left:58.56px;top:317.30px" class="cls_002"><span class="cls_002">structed from a two-feature strong classifier by reducing the</span></div>
<div style="position:absolute;left:317.28px;top:318.50px" class="cls_002"><span class="cls_002">fast average detection times.  On a difficult dataset, con-</span></div>
<div style="position:absolute;left:58.56px;top:329.30px" class="cls_002"><span class="cls_002">threshold to minimize false negatives. Measured against a</span></div>
<div style="position:absolute;left:317.28px;top:330.50px" class="cls_002"><span class="cls_002">taining 507 faces and 75 million sub-windows, faces are</span></div>
<div style="position:absolute;left:58.56px;top:341.18px" class="cls_002"><span class="cls_002">validation training set, the threshold can be adjusted to de-</span></div>
<div style="position:absolute;left:317.28px;top:342.38px" class="cls_002"><span class="cls_002">detected using an average of 10 feature evaluations per sub-</span></div>
<div style="position:absolute;left:58.56px;top:353.18px" class="cls_002"><span class="cls_002">tect 100% of the faces with a false positive rate of 40%. See</span></div>
<div style="position:absolute;left:317.28px;top:354.38px" class="cls_002"><span class="cls_002">window. In comparison, this system is about 15 times faster</span></div>
<div style="position:absolute;left:58.56px;top:365.18px" class="cls_002"><span class="cls_002">Figure 3 for a description of the two features used in this</span></div>
<div style="position:absolute;left:317.28px;top:366.38px" class="cls_002"><span class="cls_002">than an implementation of the detection system constructed</span></div>
<div style="position:absolute;left:58.56px;top:377.06px" class="cls_002"><span class="cls_002">classifier.</span></div>
<div style="position:absolute;left:317.28px;top:377.65px" class="cls_002"><span class="cls_002">by Rowley et al.</span><span class="cls_011"><sup>3</sup></span><span class="cls_002"> [12]</span></div>
<div style="position:absolute;left:329.16px;top:390.50px" class="cls_002"><span class="cls_002">A notion similar to the cascade appears in the face de-</span></div>
<div style="position:absolute;left:70.44px;top:397.82px" class="cls_002"><span class="cls_002">Computation of the two feature classifier amounts to</span></div>
<div style="position:absolute;left:317.28px;top:402.50px" class="cls_002"><span class="cls_002">tection system described by Rowley et al. in which two de-</span></div>
<div style="position:absolute;left:58.56px;top:409.70px" class="cls_002"><span class="cls_002">about 60 microprocessor instructions.  It seems hard to</span></div>
<div style="position:absolute;left:317.28px;top:414.38px" class="cls_002"><span class="cls_002">tection networks are used [12]. Rowley et al. used a faster</span></div>
<div style="position:absolute;left:58.56px;top:421.70px" class="cls_002"><span class="cls_002">imagine that any simpler filter could achieve higher rejec-</span></div>
<div style="position:absolute;left:317.28px;top:426.38px" class="cls_002"><span class="cls_002">yet less accurate network to prescreen the image in order to</span></div>
<div style="position:absolute;left:58.56px;top:433.70px" class="cls_002"><span class="cls_002">tion rates.  By comparison, scanning a simple image tem-</span></div>
<div style="position:absolute;left:317.28px;top:438.38px" class="cls_002"><span class="cls_002">find candidate regions for a slower more accurate network.</span></div>
<div style="position:absolute;left:58.56px;top:445.58px" class="cls_002"><span class="cls_002">plate, or a single layer perceptron, would require at least 20</span></div>
<div style="position:absolute;left:317.28px;top:450.26px" class="cls_002"><span class="cls_002">Though it is difficult to determine exactly, it appears that</span></div>
<div style="position:absolute;left:58.56px;top:457.58px" class="cls_002"><span class="cls_002">times as many operations per sub-window.</span></div>
<div style="position:absolute;left:317.28px;top:462.26px" class="cls_002"><span class="cls_002">Rowley et al.’s two network face system is the fastest exist-</span></div>
<div style="position:absolute;left:385.44px;top:473.53px" class="cls_011"><span class="cls_011">4</span></div>
<div style="position:absolute;left:317.28px;top:474.14px" class="cls_002"><span class="cls_002">ing face detector.</span></div>
<div style="position:absolute;left:70.44px;top:478.34px" class="cls_002"><span class="cls_002">The  structure  of  the  cascade  reflects  the  fact  that</span></div>
<div style="position:absolute;left:329.16px;top:486.38px" class="cls_002"><span class="cls_002">The structure of the cascaded detection process is es-</span></div>
<div style="position:absolute;left:58.56px;top:490.22px" class="cls_002"><span class="cls_002">within any single image an overwhelming majority of sub-</span></div>
<div style="position:absolute;left:317.28px;top:498.38px" class="cls_002"><span class="cls_002">sentially that of a degenerate decision tree, and as such is</span></div>
<div style="position:absolute;left:58.56px;top:502.22px" class="cls_002"><span class="cls_002">windows are negative. As such, the cascade attempts to re-</span></div>
<div style="position:absolute;left:317.28px;top:510.38px" class="cls_002"><span class="cls_002">related to the work of Amit and Geman [1]. Unlike tech-</span></div>
<div style="position:absolute;left:58.56px;top:514.10px" class="cls_002"><span class="cls_002">ject as many negatives as possible at the earliest stage pos-</span></div>
<div style="position:absolute;left:317.28px;top:522.26px" class="cls_002"><span class="cls_002">niques which use a fixed detector, Amit and Geman propose</span></div>
<div style="position:absolute;left:58.56px;top:526.10px" class="cls_002"><span class="cls_002">sible. While a positive instance will trigger the evaluation</span></div>
<div style="position:absolute;left:317.28px;top:534.26px" class="cls_002"><span class="cls_002">an alternative point of view where unusual co-occurrences</span></div>
<div style="position:absolute;left:58.56px;top:538.10px" class="cls_002"><span class="cls_002">of every classifier in the cascade, this is an exceedingly rare</span></div>
<div style="position:absolute;left:317.28px;top:546.26px" class="cls_002"><span class="cls_002">of simple image features are used to trigger the evaluation</span></div>
<div style="position:absolute;left:58.56px;top:549.98px" class="cls_002"><span class="cls_002">event.</span></div>
<div style="position:absolute;left:317.28px;top:558.14px" class="cls_002"><span class="cls_002">of a more complex detection process. In this way the full</span></div>
<div style="position:absolute;left:70.44px;top:570.74px" class="cls_002"><span class="cls_002">Much like a decision tree, subsequent classifiers are</span></div>
<div style="position:absolute;left:317.28px;top:570.14px" class="cls_002"><span class="cls_002">detection process need not be evaluated at many of the po-</span></div>
<div style="position:absolute;left:58.56px;top:582.74px" class="cls_002"><span class="cls_002">trained using those examples which pass through all the</span></div>
<div style="position:absolute;left:317.28px;top:582.02px" class="cls_002"><span class="cls_002">tential image locations and scales. While this basic insight</span></div>
<div style="position:absolute;left:58.56px;top:594.62px" class="cls_002"><span class="cls_002">previous stages.  As a result, the second classifier faces a</span></div>
<div style="position:absolute;left:328.08px;top:600.16px" class="cls_009"><span class="cls_009"><sup>3</sup></span><span class="cls_003">Henry Rowley very graciously supplied us with implementations of</span></div>
<div style="position:absolute;left:58.56px;top:606.62px" class="cls_002"><span class="cls_002">more difficult task than the first. The examples which make</span></div>
<div style="position:absolute;left:317.28px;top:610.53px" class="cls_003"><span class="cls_003">his detection system for direct comparison.  Reported results are against</span></div>
<div style="position:absolute;left:58.56px;top:618.50px" class="cls_002"><span class="cls_002">it through the first stage are “harder” than typical exam-</span></div>
<div style="position:absolute;left:317.28px;top:619.89px" class="cls_003"><span class="cls_003">his fastest system. It is difficult to determine from the published literature,</span></div>
<div style="position:absolute;left:317.28px;top:629.37px" class="cls_003"><span class="cls_003">but the Rowley-Baluja-Kanade detector is widely considered the fastest</span></div>
<div style="position:absolute;left:58.56px;top:630.50px" class="cls_002"><span class="cls_002">ples.  The more difficult examples faced by deeper classi-</span></div>
<div style="position:absolute;left:317.28px;top:638.85px" class="cls_003"><span class="cls_003">detection system and has been heavily tested on real-world problems.</span></div>
<div style="position:absolute;left:58.56px;top:642.50px" class="cls_002"><span class="cls_002">fiers push the entire receiver operating characteristic (ROC)</span></div>
<div style="position:absolute;left:328.08px;top:647.80px" class="cls_009"><span class="cls_009"><sup>4</sup></span><span class="cls_003">Other published detectors have either neglected to discuss perfor-</span></div>
<div style="position:absolute;left:58.56px;top:654.38px" class="cls_002"><span class="cls_002">curve downward. At a given detection rate, deeper classi-</span></div>
<div style="position:absolute;left:317.28px;top:658.05px" class="cls_003"><span class="cls_003">mance in detail, or have never published detection and false positive rates</span></div>
<div style="position:absolute;left:58.56px;top:666.38px" class="cls_002"><span class="cls_002">fiers have correspondingly higher false positive rates.</span></div>
<div style="position:absolute;left:317.28px;top:667.53px" class="cls_003"><span class="cls_003">on a large and difficult training set.</span></div>
<div style="position:absolute;left:303.48px;top:695.42px" class="cls_002"><span class="cls_002">5</span></div>
</div>
<div style="position:absolute;left:50%;margin-left:-306px;top:4010px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background6.jpg" width=612 height=792></div>
<div style="position:absolute;left:58.56px;top:7.70px" class="cls_002"><span class="cls_002">is very valuable, in their implementation it is necessary to</span></div>
<div style="position:absolute;left:58.56px;top:19.70px" class="cls_002"><span class="cls_002">first evaluate some feature detector at every location. These</span></div>
<div style="position:absolute;left:58.56px;top:31.58px" class="cls_002"><span class="cls_002">features are then grouped to find unusual co-occurrences. In</span></div>
<div style="position:absolute;left:58.56px;top:43.58px" class="cls_002"><span class="cls_002">practice, since the form of our detector and the features that</span></div>
<div style="position:absolute;left:58.56px;top:55.58px" class="cls_002"><span class="cls_002">it uses are extremely efficient, the amortized cost of evalu-</span></div>
<div style="position:absolute;left:58.56px;top:67.46px" class="cls_002"><span class="cls_002">ating our detector at</span><span class="cls_008"> every scale and location</span><span class="cls_002"> is much faster</span></div>
<div style="position:absolute;left:58.56px;top:79.46px" class="cls_002"><span class="cls_002">than finding and grouping edges throughout the image.</span></div>
<div style="position:absolute;left:70.44px;top:92.18px" class="cls_002"><span class="cls_002">In recent work Fleuret and Geman have presented a face</span></div>
<div style="position:absolute;left:58.56px;top:104.18px" class="cls_002"><span class="cls_002">detection technique which relies on a “chain” of tests in or-</span></div>
<div style="position:absolute;left:58.56px;top:116.06px" class="cls_002"><span class="cls_002">der to signify the presence of a face at a particular scale and</span></div>
<div style="position:absolute;left:58.56px;top:128.06px" class="cls_002"><span class="cls_002">location [4]. The image properties measured by Fleuret and</span></div>
<div style="position:absolute;left:58.56px;top:139.94px" class="cls_002"><span class="cls_002">Geman, disjunctions of fine scale edges, are quite different</span></div>
<div style="position:absolute;left:58.56px;top:151.94px" class="cls_002"><span class="cls_002">than rectangle features which are simple, exist at all scales,</span></div>
<div style="position:absolute;left:58.56px;top:163.94px" class="cls_002"><span class="cls_002">and are somewhat interpretable. The two approaches also</span></div>
<div style="position:absolute;left:58.56px;top:175.82px" class="cls_002"><span class="cls_002">differ radically in their learning philosophy. The motivation</span></div>
<div style="position:absolute;left:58.56px;top:187.82px" class="cls_002"><span class="cls_002">for Fleuret and Geman’s learning process is density estima-</span></div>
<div style="position:absolute;left:58.56px;top:199.82px" class="cls_002"><span class="cls_002">tion and density discrimination, while our detector is purely</span></div>
<div style="position:absolute;left:58.56px;top:211.70px" class="cls_002"><span class="cls_002">discriminative. Finally the false positive rate of Fleuret and</span></div>
<div style="position:absolute;left:317.28px;top:218.06px" class="cls_002"><span class="cls_002">Figure 5: Example of frontal upright face images used for</span></div>
<div style="position:absolute;left:58.56px;top:223.70px" class="cls_002"><span class="cls_002">Geman’s approach appears to be higher than that of previ-</span></div>
<div style="position:absolute;left:317.28px;top:230.06px" class="cls_002"><span class="cls_002">training.</span></div>
<div style="position:absolute;left:58.56px;top:235.58px" class="cls_002"><span class="cls_002">ous approaches like Rowley et al. and this approach. Un-</span></div>
<div style="position:absolute;left:58.56px;top:247.58px" class="cls_002"><span class="cls_002">fortunately the paper does not report quantitative results of</span></div>
<div style="position:absolute;left:58.56px;top:259.58px" class="cls_002"><span class="cls_002">this kind. The included example images each have between</span></div>
<div style="position:absolute;left:58.56px;top:271.46px" class="cls_002"><span class="cls_002">2 and 10 false positives.</span></div>
<div style="position:absolute;left:329.16px;top:274.82px" class="cls_002"><span class="cls_002">The speed of the cascaded detector is directly related to</span></div>
<div style="position:absolute;left:317.28px;top:286.82px" class="cls_002"><span class="cls_002">the number of features evaluated per scanned sub-window.</span></div>
<div style="position:absolute;left:317.28px;top:298.82px" class="cls_002"><span class="cls_002">Evaluated on the MIT+CMU test set [12], an average of 10</span></div>
<div style="position:absolute;left:58.56px;top:304.99px" class="cls_007"><span class="cls_007">5</span></div>
<div style="position:absolute;left:80.02px;top:304.99px" class="cls_007"><span class="cls_007">Results</span></div>
<div style="position:absolute;left:317.28px;top:310.70px" class="cls_002"><span class="cls_002">features out of a total of 6061 are evaluated per sub-window.</span></div>
<div style="position:absolute;left:317.28px;top:322.70px" class="cls_002"><span class="cls_002">This is possible because a large majority of sub-windows</span></div>
<div style="position:absolute;left:58.56px;top:333.14px" class="cls_002"><span class="cls_002">A 38 layer cascaded classifier was trained to detect frontal</span></div>
<div style="position:absolute;left:317.28px;top:334.70px" class="cls_002"><span class="cls_002">are rejected by the first or second layer in the cascade. On</span></div>
<div style="position:absolute;left:58.56px;top:345.14px" class="cls_002"><span class="cls_002">upright faces. To train the detector, a set of face and non-</span></div>
<div style="position:absolute;left:317.28px;top:346.58px" class="cls_002"><span class="cls_002">a 700 Mhz Pentium III processor, the face detector can pro-</span></div>
<div style="position:absolute;left:58.56px;top:357.14px" class="cls_002"><span class="cls_002">face training images were used. The face training set con-</span></div>
<div style="position:absolute;left:317.28px;top:358.58px" class="cls_002"><span class="cls_002">cess a 384 by 288 pixel image in about .067 seconds (us-</span></div>
<div style="position:absolute;left:58.56px;top:369.02px" class="cls_002"><span class="cls_002">sisted of 4916 hand labeled faces scaled and aligned to a</span></div>
<div style="position:absolute;left:317.28px;top:370.46px" class="cls_002"><span class="cls_002">ing a starting scale of 1.25 and a step size of 1.5 described</span></div>
<div style="position:absolute;left:58.56px;top:381.02px" class="cls_002"><span class="cls_002">base resolution of 24 by 24 pixels.  The faces were ex-</span></div>
<div style="position:absolute;left:317.28px;top:382.46px" class="cls_002"><span class="cls_002">below).  This is roughly 15 times faster than the Rowley-</span></div>
<div style="position:absolute;left:58.56px;top:393.02px" class="cls_002"><span class="cls_002">tracted from images downloaded during a random crawl of</span></div>
<div style="position:absolute;left:317.28px;top:394.46px" class="cls_002"><span class="cls_002">Baluja-Kanade detector [12] and about 600 times faster than</span></div>
<div style="position:absolute;left:58.56px;top:404.90px" class="cls_002"><span class="cls_002">the world wide web. Some typical face examples are shown</span></div>
<div style="position:absolute;left:317.28px;top:406.34px" class="cls_002"><span class="cls_002">the Schneiderman-Kanade detector [15].</span></div>
<div style="position:absolute;left:58.56px;top:416.90px" class="cls_002"><span class="cls_002">in Figure 5.  The non-face subwindows used to train the</span></div>
<div style="position:absolute;left:58.56px;top:428.78px" class="cls_002"><span class="cls_002">detector come from 9544 images which were manually in-</span></div>
<div style="position:absolute;left:317.28px;top:426.98px" class="cls_019"><span class="cls_019">Image Processing</span></div>
<div style="position:absolute;left:58.56px;top:440.78px" class="cls_002"><span class="cls_002">spected and found to not contain any faces. There are about</span></div>
<div style="position:absolute;left:329.16px;top:440.30px" class="cls_002"><span class="cls_002">All example sub-windows used for training were vari-</span></div>
<div style="position:absolute;left:58.56px;top:452.78px" class="cls_002"><span class="cls_002">350 million subwindows within these non-face images.</span></div>
<div style="position:absolute;left:317.28px;top:452.30px" class="cls_002"><span class="cls_002">ance normalized to minimize the effect of different light-</span></div>
<div style="position:absolute;left:70.44px;top:465.50px" class="cls_002"><span class="cls_002">The number of features in the first five layers of the de-</span></div>
<div style="position:absolute;left:317.28px;top:464.18px" class="cls_002"><span class="cls_002">ing conditions. Normalization is therefore necessary during</span></div>
<div style="position:absolute;left:58.56px;top:477.50px" class="cls_002"><span class="cls_002">tector is 1, 10, 25, 25 and 50 features respectively.  The</span></div>
<div style="position:absolute;left:317.28px;top:476.18px" class="cls_002"><span class="cls_002">detection as well.  The variance of an image sub-window</span></div>
<div style="position:absolute;left:58.56px;top:489.38px" class="cls_002"><span class="cls_002">remaining layers have increasingly more features. The total</span></div>
<div style="position:absolute;left:317.28px;top:488.18px" class="cls_002"><span class="cls_002">can be computed quickly using a pair of integral images.</span></div>
<div style="position:absolute;left:58.56px;top:501.38px" class="cls_002"><span class="cls_002">number of features in all layers is 6061.</span></div>
<div style="position:absolute;left:317.28px;top:500.06px" class="cls_002"><span class="cls_002">Recall that</span></div>
<div style="position:absolute;left:451.20px;top:500.06px" class="cls_002"><span class="cls_002">, where   is the standard</span></div>
<div style="position:absolute;left:70.44px;top:514.10px" class="cls_002"><span class="cls_002">Each classifier in the cascade was trained with the 4916</span></div>
<div style="position:absolute;left:317.28px;top:512.06px" class="cls_002"><span class="cls_002">deviation,</span></div>
<div style="position:absolute;left:372.45px;top:512.06px" class="cls_002"><span class="cls_002">is the mean, and   is the pixel value within</span></div>
<div style="position:absolute;left:58.56px;top:526.10px" class="cls_002"><span class="cls_002">training faces (plus their vertical mirror images for a total</span></div>
<div style="position:absolute;left:317.28px;top:524.06px" class="cls_002"><span class="cls_002">the sub-window. The mean of a sub-window can be com-</span></div>
<div style="position:absolute;left:58.56px;top:537.98px" class="cls_002"><span class="cls_002">of 9832 training faces) and 10,000 non-face sub-windows</span></div>
<div style="position:absolute;left:317.28px;top:535.94px" class="cls_002"><span class="cls_002">puted using the integral image. The sum of squared pixels</span></div>
<div style="position:absolute;left:58.56px;top:549.98px" class="cls_002"><span class="cls_002">(also of size 24 by 24 pixels) using the Adaboost training</span></div>
<div style="position:absolute;left:317.28px;top:547.94px" class="cls_002"><span class="cls_002">is computed using an integral image of the image squared</span></div>
<div style="position:absolute;left:58.56px;top:561.86px" class="cls_002"><span class="cls_002">procedure.  For the initial one feature classifier, the non-</span></div>
<div style="position:absolute;left:317.28px;top:559.82px" class="cls_002"><span class="cls_002">(i.e. two integral images are used in the scanning process).</span></div>
<div style="position:absolute;left:58.56px;top:573.86px" class="cls_002"><span class="cls_002">face training examples were collected by selecting random</span></div>
<div style="position:absolute;left:317.28px;top:571.82px" class="cls_002"><span class="cls_002">During scanning the effect of image normalization can be</span></div>
<div style="position:absolute;left:58.56px;top:585.86px" class="cls_002"><span class="cls_002">sub-windows from a set of 9544 images which did not con-</span></div>
<div style="position:absolute;left:317.28px;top:583.82px" class="cls_002"><span class="cls_002">achieved by post-multiplying the feature values rather than</span></div>
<div style="position:absolute;left:58.56px;top:597.74px" class="cls_002"><span class="cls_002">tain faces. The non-face examples used to train subsequent</span></div>
<div style="position:absolute;left:317.28px;top:595.70px" class="cls_002"><span class="cls_002">pre-multiplying the pixels.</span></div>
<div style="position:absolute;left:58.56px;top:609.74px" class="cls_002"><span class="cls_002">layers were obtained by scanning the partial cascade across</span></div>
<div style="position:absolute;left:317.28px;top:616.34px" class="cls_019"><span class="cls_019">Scanning the Detector</span></div>
<div style="position:absolute;left:58.56px;top:621.74px" class="cls_002"><span class="cls_002">the non-face images and collecting false positives. A max-</span></div>
<div style="position:absolute;left:329.16px;top:629.66px" class="cls_002"><span class="cls_002">The final detector is scanned across the image at multi-</span></div>
<div style="position:absolute;left:58.56px;top:633.62px" class="cls_002"><span class="cls_002">imum of 10000 such non-face sub-windows were collected</span></div>
<div style="position:absolute;left:317.28px;top:641.66px" class="cls_002"><span class="cls_002">ple scales and locations. Scaling is achieved by scaling the</span></div>
<div style="position:absolute;left:58.56px;top:645.62px" class="cls_002"><span class="cls_002">for each layer.</span></div>
<div style="position:absolute;left:317.28px;top:653.54px" class="cls_002"><span class="cls_002">detector itself, rather than scaling the image. This process</span></div>
<div style="position:absolute;left:58.56px;top:665.54px" class="cls_019"><span class="cls_019">Speed of the Final Detector</span></div>
<div style="position:absolute;left:317.28px;top:665.54px" class="cls_002"><span class="cls_002">makes sense because the features can be evaluated at any</span></div>
<div style="position:absolute;left:303.48px;top:695.42px" class="cls_002"><span class="cls_002">6</span></div>
</div>
<div style="position:absolute;left:50%;margin-left:-306px;top:4812px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background7.jpg" width=612 height=792></div>
<div style="position:absolute;left:178.44px;top:20.01px" class="cls_003"><span class="cls_003">False detections</span></div>
<div style="position:absolute;left:128.64px;top:39.93px" class="cls_003"><span class="cls_003">Detector</span></div>
<div style="position:absolute;left:270.12px;top:44.97px" class="cls_003"><span class="cls_003">10</span></div>
<div style="position:absolute;left:302.69px;top:44.97px" class="cls_003"><span class="cls_003">31</span></div>
<div style="position:absolute;left:335.38px;top:44.97px" class="cls_003"><span class="cls_003">50</span></div>
<div style="position:absolute;left:367.95px;top:44.97px" class="cls_003"><span class="cls_003">65</span></div>
<div style="position:absolute;left:400.52px;top:44.97px" class="cls_003"><span class="cls_003">78</span></div>
<div style="position:absolute;left:438.37px;top:44.97px" class="cls_003"><span class="cls_003">95</span></div>
<div style="position:absolute;left:472.98px;top:44.97px" class="cls_003"><span class="cls_003">167</span></div>
<div style="position:absolute;left:118.68px;top:56.85px" class="cls_003"><span class="cls_003">Viola-Jones</span></div>
<div style="position:absolute;left:270.39px;top:56.85px" class="cls_003"><span class="cls_003">76.1%</span></div>
<div style="position:absolute;left:302.98px;top:56.85px" class="cls_003"><span class="cls_003">88.4%</span></div>
<div style="position:absolute;left:335.69px;top:56.85px" class="cls_003"><span class="cls_003">91.4%</span></div>
<div style="position:absolute;left:368.27px;top:56.85px" class="cls_003"><span class="cls_003">92.0%</span></div>
<div style="position:absolute;left:400.86px;top:56.85px" class="cls_003"><span class="cls_003">92.1%</span></div>
<div style="position:absolute;left:438.73px;top:56.85px" class="cls_003"><span class="cls_003">92.9%</span></div>
<div style="position:absolute;left:473.35px;top:56.85px" class="cls_003"><span class="cls_003">93.9%</span></div>
<div style="position:absolute;left:118.68px;top:66.69px" class="cls_003"><span class="cls_003">Viola-Jones (voting)</span></div>
<div style="position:absolute;left:270.63px;top:66.69px" class="cls_003"><span class="cls_003">81.1%</span></div>
<div style="position:absolute;left:303.22px;top:66.69px" class="cls_003"><span class="cls_003">89.7%</span></div>
<div style="position:absolute;left:335.93px;top:66.69px" class="cls_003"><span class="cls_003">92.1%</span></div>
<div style="position:absolute;left:368.51px;top:66.69px" class="cls_003"><span class="cls_003">93.1%</span></div>
<div style="position:absolute;left:401.10px;top:66.69px" class="cls_003"><span class="cls_003">93.1%</span></div>
<div style="position:absolute;left:438.97px;top:66.69px" class="cls_003"><span class="cls_003">93.2 %</span></div>
<div style="position:absolute;left:473.59px;top:66.69px" class="cls_003"><span class="cls_003">93.7%</span></div>
<div style="position:absolute;left:118.68px;top:76.53px" class="cls_003"><span class="cls_003">Rowley-Baluja-Kanade</span></div>
<div style="position:absolute;left:270.85px;top:76.53px" class="cls_003"><span class="cls_003">83.2%</span></div>
<div style="position:absolute;left:303.44px;top:76.53px" class="cls_003"><span class="cls_003">86.0%</span></div>
<div style="position:absolute;left:336.15px;top:76.53px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:368.68px;top:76.53px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:401.21px;top:76.53px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:439.03px;top:76.53px" class="cls_003"><span class="cls_003">89.2%</span></div>
<div style="position:absolute;left:473.66px;top:76.53px" class="cls_003"><span class="cls_003">90.1%</span></div>
<div style="position:absolute;left:118.68px;top:86.37px" class="cls_003"><span class="cls_003">Schneiderman-Kanade</span></div>
<div style="position:absolute;left:270.71px;top:86.37px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:303.25px;top:86.37px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:335.90px;top:86.37px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:368.43px;top:86.37px" class="cls_003"><span class="cls_003">94.4%</span></div>
<div style="position:absolute;left:401.02px;top:86.37px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:438.83px;top:86.37px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:473.41px;top:86.37px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:118.68px;top:96.21px" class="cls_003"><span class="cls_003">Roth-Yang-Ahuja</span></div>
<div style="position:absolute;left:270.55px;top:96.21px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:303.09px;top:96.21px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:335.74px;top:96.21px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:368.27px;top:96.21px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:400.81px;top:96.21px" class="cls_003"><span class="cls_003">(94.8%)</span></div>
<div style="position:absolute;left:438.70px;top:96.21px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:473.28px;top:96.21px" class="cls_003"><span class="cls_003">-</span></div>
<div style="position:absolute;left:58.56px;top:115.22px" class="cls_002"><span class="cls_002">Table 2: Detection rates for various numbers of false positives on the MIT+CMU test set containing 130 images and 507</span></div>
<div style="position:absolute;left:58.56px;top:127.22px" class="cls_002"><span class="cls_002">faces.</span></div>
<div style="position:absolute;left:58.56px;top:167.18px" class="cls_002"><span class="cls_002">scale with the same cost. Good results were obtained using</span></div>
<div style="position:absolute;left:317.28px;top:167.18px" class="cls_002"><span class="cls_002">Thus, in order to construct a complete ROC curve, classifier</span></div>
<div style="position:absolute;left:58.56px;top:179.18px" class="cls_002"><span class="cls_002">a set of scales a factor of 1.25 apart.</span></div>
<div style="position:absolute;left:317.28px;top:179.18px" class="cls_002"><span class="cls_002">layers are removed. We use the</span><span class="cls_008"> number</span><span class="cls_002"> of false positives as</span></div>
<div style="position:absolute;left:70.44px;top:191.90px" class="cls_002"><span class="cls_002">The detector is also scanned across location. Subsequent</span></div>
<div style="position:absolute;left:317.28px;top:191.06px" class="cls_002"><span class="cls_002">opposed to the</span><span class="cls_008"> rate</span><span class="cls_002"> of false positives for the x-axis of the</span></div>
<div style="position:absolute;left:58.56px;top:203.90px" class="cls_002"><span class="cls_002">locations are obtained by shifting the window some number</span></div>
<div style="position:absolute;left:317.28px;top:203.06px" class="cls_002"><span class="cls_002">ROC curve to facilitate comparison with other systems. To</span></div>
<div style="position:absolute;left:58.56px;top:215.78px" class="cls_002"><span class="cls_002">of pixels</span></div>
<div style="position:absolute;left:103.26px;top:215.78px" class="cls_002"><span class="cls_002">. This shifting process is affected by the scale of</span></div>
<div style="position:absolute;left:317.28px;top:215.06px" class="cls_002"><span class="cls_002">compute the false positive rate, simply divide by the total</span></div>
<div style="position:absolute;left:58.56px;top:227.78px" class="cls_002"><span class="cls_002">the detector: if the current scale is   the window is shifted</span></div>
<div style="position:absolute;left:317.28px;top:226.94px" class="cls_002"><span class="cls_002">number of sub-windows scanned. In our experiments, the</span></div>
<div style="position:absolute;left:58.56px;top:239.78px" class="cls_002"><span class="cls_002">by</span></div>
<div style="position:absolute;left:89.28px;top:239.78px" class="cls_002"><span class="cls_002">, where  is the rounding operation.</span></div>
<div style="position:absolute;left:317.28px;top:238.94px" class="cls_002"><span class="cls_002">number of sub-windows scanned is 75,081,800.</span></div>
<div style="position:absolute;left:70.44px;top:252.50px" class="cls_002"><span class="cls_002">The choice of   affects both the speed of the detector as</span></div>
<div style="position:absolute;left:329.16px;top:251.30px" class="cls_002"><span class="cls_002">Unfortunately, most previous published results on face</span></div>
<div style="position:absolute;left:58.56px;top:264.50px" class="cls_002"><span class="cls_002">well as accuracy. The results we present are for</span></div>
<div style="position:absolute;left:317.28px;top:263.18px" class="cls_002"><span class="cls_002">detection have only included a single operating regime (i.e.</span></div>
<div style="position:absolute;left:58.56px;top:276.38px" class="cls_002"><span class="cls_002">We can achieve a significant speedup by setting</span></div>
<div style="position:absolute;left:317.28px;top:275.18px" class="cls_002"><span class="cls_002">single point on the ROC curve). To make comparison with</span></div>
<div style="position:absolute;left:58.56px;top:288.38px" class="cls_002"><span class="cls_002">with only a slight decrease in accuracy.</span></div>
<div style="position:absolute;left:317.28px;top:287.18px" class="cls_002"><span class="cls_002">our detector easier we have listed our detection rate for the</span></div>
<div style="position:absolute;left:317.28px;top:299.06px" class="cls_002"><span class="cls_002">false positive rates reported by the other systems. Table 2</span></div>
<div style="position:absolute;left:58.56px;top:308.30px" class="cls_019"><span class="cls_019">Integration of Multiple Detections</span></div>
<div style="position:absolute;left:317.28px;top:311.06px" class="cls_002"><span class="cls_002">lists the detection rate for various numbers of false detec-</span></div>
<div style="position:absolute;left:70.44px;top:321.14px" class="cls_002"><span class="cls_002">Since the final detector is insensitive to small changes in</span></div>
<div style="position:absolute;left:317.28px;top:322.94px" class="cls_002"><span class="cls_002">tions for our system as well as other published systems. For</span></div>
<div style="position:absolute;left:58.56px;top:333.14px" class="cls_002"><span class="cls_002">translation and scale, multiple detections will usually occur</span></div>
<div style="position:absolute;left:317.28px;top:334.94px" class="cls_002"><span class="cls_002">the Rowley-Baluja-Kanade results [12], a number of differ-</span></div>
<div style="position:absolute;left:58.56px;top:345.02px" class="cls_002"><span class="cls_002">around each face in a scanned image. The same is often true</span></div>
<div style="position:absolute;left:317.28px;top:346.94px" class="cls_002"><span class="cls_002">ent versions of their detector were tested yielding a number</span></div>
<div style="position:absolute;left:58.56px;top:357.02px" class="cls_002"><span class="cls_002">of some types of false positives. In practice it often makes</span></div>
<div style="position:absolute;left:317.28px;top:358.82px" class="cls_002"><span class="cls_002">of different results they are all listed in under the same head-</span></div>
<div style="position:absolute;left:58.56px;top:368.90px" class="cls_002"><span class="cls_002">sense to return one final detection per face. Toward this end</span></div>
<div style="position:absolute;left:317.28px;top:370.82px" class="cls_002"><span class="cls_002">ing. For the Roth-Yang-Ahuja detector [11], they reported</span></div>
<div style="position:absolute;left:58.56px;top:380.90px" class="cls_002"><span class="cls_002">it is useful to postprocess the detected sub-windows in order</span></div>
<div style="position:absolute;left:317.28px;top:382.82px" class="cls_002"><span class="cls_002">their result on the MIT+CMU test set minus 5 images con-</span></div>
<div style="position:absolute;left:58.56px;top:392.90px" class="cls_002"><span class="cls_002">to combine overlapping detections into a single detection.</span></div>
<div style="position:absolute;left:317.28px;top:394.70px" class="cls_002"><span class="cls_002">taining line drawn faces removed.</span></div>
<div style="position:absolute;left:70.44px;top:405.62px" class="cls_002"><span class="cls_002">In these experiments detections are combined in a very</span></div>
<div style="position:absolute;left:329.16px;top:407.06px" class="cls_002"><span class="cls_002">Figure 7 shows the output of our face detector on some</span></div>
<div style="position:absolute;left:58.56px;top:417.62px" class="cls_002"><span class="cls_002">simple fashion.  The set of detections are first partitioned</span></div>
<div style="position:absolute;left:317.28px;top:419.06px" class="cls_002"><span class="cls_002">test images from the MIT+CMU test set.</span></div>
<div style="position:absolute;left:58.56px;top:429.50px" class="cls_002"><span class="cls_002">into disjoint subsets. Two detections are in the same subset</span></div>
<div style="position:absolute;left:317.28px;top:438.62px" class="cls_019"><span class="cls_019">A simple voting scheme to further improve results</span></div>
<div style="position:absolute;left:58.56px;top:441.50px" class="cls_002"><span class="cls_002">if their bounding regions overlap.  Each partition yields a</span></div>
<div style="position:absolute;left:329.16px;top:450.98px" class="cls_002"><span class="cls_002">In table 2 we also show results from running three de-</span></div>
<div style="position:absolute;left:58.56px;top:453.50px" class="cls_002"><span class="cls_002">single final detection.  The corners of the final bounding</span></div>
<div style="position:absolute;left:317.28px;top:462.86px" class="cls_002"><span class="cls_002">tectors (the 38 layer one described above plus two similarly</span></div>
<div style="position:absolute;left:58.56px;top:465.38px" class="cls_002"><span class="cls_002">region are the average of the corners of all detections in the</span></div>
<div style="position:absolute;left:317.28px;top:474.86px" class="cls_002"><span class="cls_002">trained detectors) and outputting the majority vote of the</span></div>
<div style="position:absolute;left:58.56px;top:477.38px" class="cls_002"><span class="cls_002">set.</span></div>
<div style="position:absolute;left:317.28px;top:486.74px" class="cls_002"><span class="cls_002">three detectors. This improves the detection rate as well as</span></div>
<div style="position:absolute;left:58.56px;top:497.30px" class="cls_019"><span class="cls_019">Experiments on a Real-World Test Set</span></div>
<div style="position:absolute;left:317.28px;top:498.74px" class="cls_002"><span class="cls_002">eliminating more false positives. The improvement would</span></div>
<div style="position:absolute;left:70.44px;top:510.14px" class="cls_002"><span class="cls_002">We tested our system on the MIT+CMU frontal face test</span></div>
<div style="position:absolute;left:317.28px;top:510.74px" class="cls_002"><span class="cls_002">be greater if the detectors were more independent. The cor-</span></div>
<div style="position:absolute;left:58.56px;top:522.02px" class="cls_002"><span class="cls_002">set [12]. This set consists of 130 images with 507 labeled</span></div>
<div style="position:absolute;left:317.28px;top:522.62px" class="cls_002"><span class="cls_002">relation of their errors results in a modest improvement over</span></div>
<div style="position:absolute;left:58.56px;top:534.02px" class="cls_002"><span class="cls_002">frontal faces. A ROC curve showing the performance of our</span></div>
<div style="position:absolute;left:317.28px;top:534.62px" class="cls_002"><span class="cls_002">the best single detector.</span></div>
<div style="position:absolute;left:58.56px;top:546.02px" class="cls_002"><span class="cls_002">detector on this test set is shown in Figure 6. To create the</span></div>
<div style="position:absolute;left:58.56px;top:557.90px" class="cls_002"><span class="cls_002">ROC curve the threshold of the final layer classifier is ad-</span></div>
<div style="position:absolute;left:58.56px;top:569.90px" class="cls_002"><span class="cls_002">justed from</span></div>
<div style="position:absolute;left:129.45px;top:569.90px" class="cls_002"><span class="cls_002">to</span></div>
<div style="position:absolute;left:158.32px;top:569.90px" class="cls_002"><span class="cls_002">. Adjusting the threshold to</span></div>
<div style="position:absolute;left:317.28px;top:565.99px" class="cls_007"><span class="cls_007">6</span></div>
<div style="position:absolute;left:338.74px;top:565.99px" class="cls_007"><span class="cls_007">Conclusions</span></div>
<div style="position:absolute;left:58.56px;top:581.90px" class="cls_002"><span class="cls_002">will yield a detection rate of 0.0 and a false positive rate</span></div>
<div style="position:absolute;left:58.56px;top:593.78px" class="cls_002"><span class="cls_002">of 0.0. Adjusting the threshold to</span></div>
<div style="position:absolute;left:213.39px;top:593.78px" class="cls_002"><span class="cls_002">, however, increases</span></div>
<div style="position:absolute;left:317.28px;top:593.42px" class="cls_002"><span class="cls_002">We have presented an approach for object detection which</span></div>
<div style="position:absolute;left:58.56px;top:605.78px" class="cls_002"><span class="cls_002">both the detection rate and false positive rate, but only to a</span></div>
<div style="position:absolute;left:317.28px;top:605.42px" class="cls_002"><span class="cls_002">minimizes computation time while achieving high detection</span></div>
<div style="position:absolute;left:58.56px;top:617.66px" class="cls_002"><span class="cls_002">certain point. Neither rate can be higher than the rate of the</span></div>
<div style="position:absolute;left:317.28px;top:617.30px" class="cls_002"><span class="cls_002">accuracy.  The approach was used to construct a face de-</span></div>
<div style="position:absolute;left:58.56px;top:629.66px" class="cls_002"><span class="cls_002">detection cascade minus the final layer. In effect, a thresh-</span></div>
<div style="position:absolute;left:317.28px;top:629.30px" class="cls_002"><span class="cls_002">tection system which is approximately 15 faster than any</span></div>
<div style="position:absolute;left:58.56px;top:641.66px" class="cls_002"><span class="cls_002">old of</span></div>
<div style="position:absolute;left:108.63px;top:641.66px" class="cls_002"><span class="cls_002">is equivalent to removing that layer.  Further</span></div>
<div style="position:absolute;left:317.28px;top:641.18px" class="cls_002"><span class="cls_002">previous approach.</span></div>
<div style="position:absolute;left:58.56px;top:653.54px" class="cls_002"><span class="cls_002">increasing the detection and false positive rates requires de-</span></div>
<div style="position:absolute;left:329.16px;top:653.54px" class="cls_002"><span class="cls_002">This paper brings together new algorithms, representa-</span></div>
<div style="position:absolute;left:58.56px;top:665.54px" class="cls_002"><span class="cls_002">creasing the threshold of the next classifier in the cascade.</span></div>
<div style="position:absolute;left:317.28px;top:665.54px" class="cls_002"><span class="cls_002">tions, and insights which are quite generic and may well</span></div>
<div style="position:absolute;left:303.48px;top:695.42px" class="cls_002"><span class="cls_002">7</span></div>
</div>
<div style="position:absolute;left:50%;margin-left:-306px;top:5614px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background8.jpg" width=612 height=792></div>
<div style="position:absolute;left:118.44px;top:138.74px" class="cls_002"><span class="cls_002">Figure 7: Output of our face detector on a number of test images from the MIT+CMU test set.</span></div>
<div style="position:absolute;left:321.72px;top:181.73px" class="cls_015"><span class="cls_015">[3]</span></div>
<div style="position:absolute;left:337.22px;top:181.73px" class="cls_015"><span class="cls_015">F. Crow.   Summed-area tables for texture mapping.   In</span></div>
<div style="position:absolute;left:337.20px;top:192.65px" class="cls_020"><span class="cls_020">Proceedings of SIGGRAPH</span><span class="cls_015">, volume 18(3), pages 207-212,</span></div>
<div style="position:absolute;left:337.20px;top:203.57px" class="cls_015"><span class="cls_015">1984.</span></div>
<div style="position:absolute;left:321.72px;top:217.49px" class="cls_015"><span class="cls_015">[4]</span></div>
<div style="position:absolute;left:337.22px;top:217.49px" class="cls_015"><span class="cls_015">F. Fleuret and D. Geman. Coarse-to-fine face detection.</span><span class="cls_020"> Int.</span></div>
<div style="position:absolute;left:337.20px;top:228.53px" class="cls_020"><span class="cls_020">J. Computer Vision</span><span class="cls_015">, 2001.</span></div>
<div style="position:absolute;left:321.72px;top:242.45px" class="cls_015"><span class="cls_015">[5]</span></div>
<div style="position:absolute;left:337.22px;top:242.45px" class="cls_015"><span class="cls_015">William T. Freeman and Edward H. Adelson.  The design</span></div>
<div style="position:absolute;left:337.20px;top:253.37px" class="cls_015"><span class="cls_015">and use of steerable filters.</span><span class="cls_020">  IEEE Transactions on Pattern</span></div>
<div style="position:absolute;left:337.20px;top:264.29px" class="cls_020"><span class="cls_020">Analysis and Machine Intelligence</span><span class="cls_015">, 13(9):891-906, 1991.</span></div>
<div style="position:absolute;left:321.72px;top:278.21px" class="cls_015"><span class="cls_015">[6]</span></div>
<div style="position:absolute;left:337.22px;top:278.21px" class="cls_015"><span class="cls_015">Yoav Freund and Robert E. Schapire.  A decision-theoretic</span></div>
<div style="position:absolute;left:337.20px;top:289.25px" class="cls_015"><span class="cls_015">generalization  of on-line learning  and an  application to</span></div>
<div style="position:absolute;left:337.20px;top:300.17px" class="cls_015"><span class="cls_015">boosting. In</span><span class="cls_020"> Computational Learning Theory: Eurocolt ’95</span><span class="cls_015">,</span></div>
<div style="position:absolute;left:337.20px;top:311.09px" class="cls_015"><span class="cls_015">pages 23-37. Springer-Verlag, 1995.</span></div>
<div style="position:absolute;left:321.72px;top:325.01px" class="cls_015"><span class="cls_015">[7]</span></div>
<div style="position:absolute;left:337.22px;top:325.01px" class="cls_015"><span class="cls_015">H. Greenspan, S. Belongie, R. Gooodman, P. Perona, S. Rak-</span></div>
<div style="position:absolute;left:337.20px;top:336.05px" class="cls_015"><span class="cls_015">shit, and C. Anderson. Overcomplete steerable pyramid fil-</span></div>
<div style="position:absolute;left:337.20px;top:346.97px" class="cls_015"><span class="cls_015">ters and rotation invariance. In</span><span class="cls_020"> Proceedings of the IEEE Con-</span></div>
<div style="position:absolute;left:337.20px;top:357.89px" class="cls_020"><span class="cls_020">ference on Computer Vision and Pattern Recognition</span><span class="cls_015">, 1994.</span></div>
<div style="position:absolute;left:321.73px;top:371.81px" class="cls_015"><span class="cls_015">[8]</span></div>
<div style="position:absolute;left:337.22px;top:371.81px" class="cls_015"><span class="cls_015">L. Itti, C. Koch, and E. Niebur. A model of saliency-based</span></div>
<div style="position:absolute;left:58.56px;top:374.06px" class="cls_002"><span class="cls_002">Figure</span></div>
<div style="position:absolute;left:91.05px;top:374.06px" class="cls_002"><span class="cls_002">6:   ROC  curve  for  our  face  detector  on  the</span></div>
<div style="position:absolute;left:337.20px;top:382.85px" class="cls_015"><span class="cls_015">visual attention for rapid scene analysis.</span><span class="cls_020">  IEEE Patt. Anal.</span></div>
<div style="position:absolute;left:58.56px;top:386.06px" class="cls_002"><span class="cls_002">MIT+CMU test set. The detector was run using a step size</span></div>
<div style="position:absolute;left:337.20px;top:393.77px" class="cls_020"><span class="cls_020">Mach. Intell.</span><span class="cls_015">, 20(11):1254-1259, November 1998.</span></div>
<div style="position:absolute;left:58.56px;top:398.06px" class="cls_002"><span class="cls_002">of 1.0 and starting scale of 1.0 (75,081,800 sub-windows</span></div>
<div style="position:absolute;left:321.72px;top:407.69px" class="cls_015"><span class="cls_015">[9]</span></div>
<div style="position:absolute;left:337.22px;top:407.69px" class="cls_015"><span class="cls_015">Edgar Osuna, Robert Freund, and Federico Girosi. Training</span></div>
<div style="position:absolute;left:58.56px;top:409.94px" class="cls_002"><span class="cls_002">scanned).</span></div>
<div style="position:absolute;left:337.20px;top:418.61px" class="cls_015"><span class="cls_015">support vector machines: an application to face detection.</span></div>
<div style="position:absolute;left:337.20px;top:429.65px" class="cls_015"><span class="cls_015">In</span><span class="cls_020"> Proceedings of the IEEE Conference on Computer Vision</span></div>
<div style="position:absolute;left:337.20px;top:440.57px" class="cls_020"><span class="cls_020">and Pattern Recognition</span><span class="cls_015">, 1997.</span></div>
<div style="position:absolute;left:58.56px;top:452.30px" class="cls_002"><span class="cls_002">have broader application in computer vision and image pro-</span></div>
<div style="position:absolute;left:317.28px;top:454.49px" class="cls_015"><span class="cls_015">[10]</span></div>
<div style="position:absolute;left:337.26px;top:454.49px" class="cls_015"><span class="cls_015">C. Papageorgiou, M. Oren, and T. Poggio. A general frame-</span></div>
<div style="position:absolute;left:58.56px;top:464.30px" class="cls_002"><span class="cls_002">cessing.</span></div>
<div style="position:absolute;left:337.20px;top:465.41px" class="cls_015"><span class="cls_015">work for object detection.  In</span><span class="cls_020"> International Conference on</span></div>
<div style="position:absolute;left:70.44px;top:476.54px" class="cls_002"><span class="cls_002">Finally this paper presents a set of detailed experiments</span></div>
<div style="position:absolute;left:337.21px;top:476.45px" class="cls_020"><span class="cls_020">Computer Vision</span><span class="cls_015">, 1998.</span></div>
<div style="position:absolute;left:58.56px;top:488.54px" class="cls_002"><span class="cls_002">on a difficult face detection dataset which has been widely</span></div>
<div style="position:absolute;left:317.28px;top:490.37px" class="cls_015"><span class="cls_015">[11]</span></div>
<div style="position:absolute;left:337.26px;top:490.37px" class="cls_015"><span class="cls_015">D. Roth, M. Yang, and N. Ahuja. A snowbased face detector.</span></div>
<div style="position:absolute;left:58.56px;top:500.42px" class="cls_002"><span class="cls_002">studied. This dataset includes faces under a very wide range</span></div>
<div style="position:absolute;left:337.20px;top:501.29px" class="cls_015"><span class="cls_015">In</span><span class="cls_020"> Neural Information Processing 12</span><span class="cls_015">, 2000.</span></div>
<div style="position:absolute;left:58.56px;top:512.42px" class="cls_002"><span class="cls_002">of conditions including: illumination, scale, pose, and cam-</span></div>
<div style="position:absolute;left:317.28px;top:515.21px" class="cls_015"><span class="cls_015">[12]</span></div>
<div style="position:absolute;left:337.26px;top:515.21px" class="cls_015"><span class="cls_015">H. Rowley, S. Baluja, and T. Kanade. Neural network-based</span></div>
<div style="position:absolute;left:58.56px;top:524.42px" class="cls_002"><span class="cls_002">era variation.  Experiments on such a large and complex</span></div>
<div style="position:absolute;left:337.21px;top:526.13px" class="cls_015"><span class="cls_015">face detection. In</span><span class="cls_020"> IEEE Patt. Anal. Mach. Intell.</span><span class="cls_015">, volume 20,</span></div>
<div style="position:absolute;left:58.56px;top:536.30px" class="cls_002"><span class="cls_002">dataset are difficult and time consuming. Nevertheless sys-</span></div>
<div style="position:absolute;left:337.21px;top:537.05px" class="cls_015"><span class="cls_015">pages 22-38, 1998.</span></div>
<div style="position:absolute;left:58.56px;top:548.30px" class="cls_002"><span class="cls_002">tems which work under these conditions are unlikely to be</span></div>
<div style="position:absolute;left:317.29px;top:550.97px" class="cls_015"><span class="cls_015">[13]</span></div>
<div style="position:absolute;left:337.26px;top:550.97px" class="cls_015"><span class="cls_015">R. E. Schapire, Y. Freund, P. Bartlett, and W. S. Lee. Boost-</span></div>
<div style="position:absolute;left:58.56px;top:560.30px" class="cls_002"><span class="cls_002">brittle or limited to a single set of conditions. More impor-</span></div>
<div style="position:absolute;left:337.21px;top:562.01px" class="cls_015"><span class="cls_015">ing the margin: a new explanation for the effectiveness of</span></div>
<div style="position:absolute;left:58.56px;top:572.18px" class="cls_002"><span class="cls_002">tantly conclusions drawn from this dataset are unlikely to</span></div>
<div style="position:absolute;left:337.21px;top:572.93px" class="cls_015"><span class="cls_015">voting methods.</span><span class="cls_020"> Ann. Stat.</span><span class="cls_015">, 26(5):1651-1686, 1998.</span></div>
<div style="position:absolute;left:58.56px;top:584.18px" class="cls_002"><span class="cls_002">be experimental artifacts.</span></div>
<div style="position:absolute;left:317.29px;top:586.85px" class="cls_015"><span class="cls_015">[14]</span></div>
<div style="position:absolute;left:337.26px;top:586.85px" class="cls_015"><span class="cls_015">Robert  E.  Schapire,  Yoav  Freund,  Peter  Bartlett,  and</span></div>
<div style="position:absolute;left:337.21px;top:597.77px" class="cls_015"><span class="cls_015">Wee Sun Lee. Boosting the margin: A new explanation for</span></div>
<div style="position:absolute;left:337.21px;top:608.81px" class="cls_015"><span class="cls_015">the effectiveness of voting methods.  In</span><span class="cls_020"> Proceedings of the</span></div>
<div style="position:absolute;left:58.56px;top:613.63px" class="cls_007"><span class="cls_007">References</span></div>
<div style="position:absolute;left:337.21px;top:619.73px" class="cls_020"><span class="cls_020">Fourteenth International Conference on Machine Learning</span><span class="cls_015">,</span></div>
<div style="position:absolute;left:337.21px;top:630.65px" class="cls_015"><span class="cls_015">1997.</span></div>
<div style="position:absolute;left:63.00px;top:639.89px" class="cls_015"><span class="cls_015">[1] Y. Amit, D. Geman, and K. Wilder. Joint induction of shape</span></div>
<div style="position:absolute;left:317.29px;top:644.57px" class="cls_015"><span class="cls_015">[15]</span></div>
<div style="position:absolute;left:337.26px;top:644.57px" class="cls_015"><span class="cls_015">H. Schneiderman and T. Kanade. A statistical method for 3D</span></div>
<div style="position:absolute;left:78.36px;top:650.81px" class="cls_015"><span class="cls_015">features and tree classifiers, 1997.</span></div>
<div style="position:absolute;left:337.21px;top:655.61px" class="cls_015"><span class="cls_015">object detection applied to faces and cars.  In</span><span class="cls_020"> International</span></div>
<div style="position:absolute;left:63.00px;top:666.53px" class="cls_015"><span class="cls_015">[2] Anonymous. Anonymous. In</span><span class="cls_020"> Anonymous</span><span class="cls_015">, 2000.</span></div>
<div style="position:absolute;left:337.21px;top:666.53px" class="cls_020"><span class="cls_020">Conference on Computer Vision</span><span class="cls_015">, 2000.</span></div>
<div style="position:absolute;left:303.49px;top:695.42px" class="cls_002"><span class="cls_002">8</span></div>
</div>
<div style="position:absolute;left:50%;margin-left:-306px;top:6416px;width:612px;height:792px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="/book/viola/background9.jpg" width=612 height=792></div>
<div style="position:absolute;left:58.56px;top:8.69px" class="cls_015"><span class="cls_015">[16] K. Sung and T. Poggio.  Example-based learning for view-</span></div>
<div style="position:absolute;left:78.36px;top:19.61px" class="cls_015"><span class="cls_015">based face detection. In</span><span class="cls_020"> IEEE Patt. Anal. Mach. Intell.</span><span class="cls_015">, vol-</span></div>
<div style="position:absolute;left:78.36px;top:30.65px" class="cls_015"><span class="cls_015">ume 20, pages 39-51, 1998.</span></div>
<div style="position:absolute;left:58.56px;top:45.53px" class="cls_015"><span class="cls_015">[17] J.K. Tsotsos, S.M. Culhane, W.Y.K. Wai, Y.H. Lai, N. Davis,</span></div>
<div style="position:absolute;left:78.36px;top:56.57px" class="cls_015"><span class="cls_015">and F. Nuflo.  Modeling visual-attention via selective tun-</span></div>
<div style="position:absolute;left:78.36px;top:67.49px" class="cls_015"><span class="cls_015">ing.</span><span class="cls_020"> Artificial Intelligence Journal</span><span class="cls_015">, 78(1-2):507-545, Octo-</span></div>
<div style="position:absolute;left:78.36px;top:78.41px" class="cls_015"><span class="cls_015">ber 1995.</span></div>
<div style="position:absolute;left:58.56px;top:93.41px" class="cls_015"><span class="cls_015">[18] Andrew Webb.</span><span class="cls_020"> Statistical Pattern Recognition</span><span class="cls_015">. Oxford Uni-</span></div>
<div style="position:absolute;left:78.36px;top:104.33px" class="cls_015"><span class="cls_015">versity Press, New York, 1999.</span></div>
<div style="position:absolute;left:303.48px;top:695.42px" class="cls_002"><span class="cls_002">9</span></div>
</div>

</body>
</html>
