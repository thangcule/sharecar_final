@extends('layouts.app_default')
	
@section('content')
<style>
	.alert-danger {
		margin-top: 0px;
		margin-bottom: 20px; 
	}
</style>
	<div class="Layout-content">
	    <div class="Home u-flex">
            <div class="HomeBlock-inner" >
                <div class="HomeBlock-media HomeBlock-media--primary HomeBlock-form" style="margin-left: 20%; width: 60%;">
					<h2 class="HomeBlock-title">Find a ride</h2>
					<form action="/ride/find" method="POST">
						{{ csrf_field() }}

						<input type="text" placeholder="Leaving from" name="pick_up" id="pick_up" class="bla-input" value="<?= !empty(old('pick_up')) ? old('pick_up') : '' ?>">
                        {!! $errors->first('p_address', '<div class="alert alert-danger">:message</div>') !!}

						<input type="text" placeholder="Going to" name="drop_off" id="drop_off" class="bla-input" value="<?= !empty(old('drop_off')) ? old('drop_off') : '' ?>">
                        {!! $errors->first('d_address', '<div class="alert alert-danger">:message</div>') !!}

						<div class="input-group date" id="date" style="width: 100%;">
							<div class="bla-datetime-input">
		                    	Date and time <br>
		                    	<input type="text" name="start_date"/ value="{{old('start_date')}}" id="start_date">
							</div>
		                    <span class="input-group-addon" style="display: none;">
		                    	<span class="glyphicon glyphicon-calendar"></span>
		                    </span>
		                </div>
                        {!! $errors->first('start_date', '<div class="alert alert-danger">:message</div>') !!}
				        <script type="text/javascript">
				        	var f = "{{old('start_date')}}".split("-");
			                $('#date').datetimepicker({
			                	format: 'DD-MM-YYYY', 
			                	date: new Date(f[2], f[1] - 1, f[0])
			                });
				            $('.bla-datetime-input').click(function () {
				                $('.glyphicon-calendar').trigger('click');
				            })
				        </script>
				   

						<input type="hidden" name="p_address" id="p_address" value="{{!empty(old('p_address')) ? old('p_address') : $find_pick_up}}">
					    <input type="hidden" name="p_lat" id="p_lat" value="{{old('p_lat')}}">
					    <input type="hidden" name="p_lng" id="p_lng" value="{{old('p_lng')}}">
					    <input type="hidden" name="d_address" id="d_address" value="{{!empty(old('d_address')) ? old('d_address') : $find_drop_off}}">
					    <input type="hidden" name="d_lat" id="d_lat" value="{{old('p_lat')}}">
					    <input type="hidden" name="d_lng" id="d_lng" value="{{old('p_lng')}}">

				        <button class="bla-btn">Search</button>
					</form>
                </div>
            </div>
	    </div>
	</div>
	<script>
		$(document).keypress(
			function(event){
				if (event.which == '13') {
					event.preventDefault();
				}
		});
		var pick_up, drop_off;
		function init_map() {
		    pick_up = new google.maps.places.Autocomplete($('#pick_up')[0]);
		    drop_off = new google.maps.places.Autocomplete($('#drop_off')[0]);
		    pick_up.addListener('place_changed', function() {
				var place = pick_up.getPlace();
				if (!place.geometry) {
		            alert("Location '" + place.name + "' invalid");
		            return;
		        }
	            $('#p_address').val(place.formatted_address); // full address
		        $('#p_lat').val(place.geometry.location.lat());
		        $('#p_lng').val(place.geometry.location.lng());
		    });
		    drop_off.addListener('place_changed', function() {
				var place = drop_off.getPlace();
				if (!place.geometry) {
		            alert("Location '" + place.name + "' invalid");
		            return;
		        }
	            $('#d_address').val(place.formatted_address); // full address
		        $('#d_lat').val(place.geometry.location.lat());
		        $('#d_lng').val(place.geometry.location.lng());
		    });
		}
	</script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCskL3zcYoYUJ7t3UITgsuIzC8fyYjy3rc&libraries=places&language=vi&callback=init_map"></script>
@stop