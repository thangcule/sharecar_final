<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'HomeController@index')->name('home');
Route::get('/clean', 'HomeController@clean')->name('clean');

Route::get('/sp_01', 'HomeController@sp_01');
Route::get('/sp_02', 'HomeController@sp_02');
Route::get('/sp_03', 'HomeController@sp_03');
Route::get('/sp_04', 'HomeController@sp_04');
Route::get('/sp_05', 'HomeController@sp_05');
Route::get('/sp_06', 'HomeController@sp_06');
Route::get('/sp_07', 'HomeController@sp_07');

Route::get('/viola', 'HomeController@viola');

/*Package Authenication*/
	Auth::routes();
	Route::group(['middleware' => ['auth']], function () {
		Route::get('/user/profile', 'Auth\UserController@profile')->name('user.profile');
		Route::post('/user/profile', 'Auth\UserController@profile');
	});

/*Package Owner*/
	/*Sub 	Ride*/
	Route::get('/ride/schedule', 'Owner\RideController@schedule')->name('ride.schedule');
	Route::post('/ride/schedule', 'Owner\RideController@schedule');
	Route::get('/ride/contribution', 'Owner\RideController@contribution')->name('ride.contribution'); 
	Route::group(['middleware' => ['auth']], function () {
		Route::post('/ride/contribution', 'Owner\RideController@contribution'); 
		Route::get('/ride/schedule_edit', 'Owner\RideController@editSchedule')->name('ride.schedule_edit');
		Route::post('/ride/schedule_edit', 'Owner\RideController@editSchedule');
		Route::get('/ride/contribution_edit', 'Owner\RideController@editContribution')->name('ride.contribution_edit');
		Route::post('/ride/contribution_edit', 'Owner\RideController@editContribution');
		
		Route::get('/user/rides_offered', 'Owner\RideController@rides_offered')->name('user.rides_offered');
	    Route::post('/user/rides_offered/delete', 'Owner\RideController@delete');	
		Route::get('/ride/detail/{id}', 'Owner\RideController@detail')->name('ride.detail');
    
    /*Sub 	Passenger*/
	    Route::get('/ride/{ride_id}/passengers', 'Owner\PassengerController@passengers')->name('ride.passengers');
	    Route::get('/ride/{ride_id}/bookmarks/{bookmark_id}/deny', 'Owner\PassengerController@deny');
	    Route::get('/ride/{ride_id}/bookmarks/{bookmark_id}/accept', 'Owner\PassengerController@accept');
	});

/*Package Booked*/

	/*Sub     Filter */
	Route::get('/ride', 'Booker\RideController@index')->name('ride.index');
	Route::get('/ride/find', 'Booker\FilterController@find')->name('ride.find');		// find page
	Route::post('/ride/find', 'Booker\FilterController@find');					// find result page

	/*Sub     Bookmark */
	Route::group(['middleware' => ['auth']], function () {
		Route::get('/bookmark/store', 'Booker\BookmarkController@store')->name('bookmark.store');
		Route::post('/user/rides_booked/delete', 'Booker\BookmarkController@delete');
		Route::get('/user/rides_booked', 'Booker\BookmarkController@rides_booked')->name('user.rides_booked');
	});
