<?php

use Illuminate\Database\Seeder;
use App\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $datas = [
            [
                'name' => 'Vu Ngoc Dang',
                'email' => 'vungocdang@gmail.com',
                'phone' => '0971053765',
                'password' => bcrypt('123456'),
            ],
            [
                'name' => 'Nguyen Dinh Tuan',
                'email' => 'nguyendinhtuan@gmail.com',
                'phone' => '3218932097',
                'password' => bcrypt('123456'),
            ],
            [
                'name' => 'Vu Cong Duy',
                'email' => 'vucongduy@gmail.com',
                'phone' => '0971053097',
                'password' => bcrypt('123456'),
            ],
            [
                'name' => 'Nguyen Viet Thai',
                'email' => 'nguyenvietthai@gmail.com',
                'phone' => '3218931324',
                'password' => bcrypt('123456'),
            ],
            [
                'name' => 'Hoang Trung Kien',
                'email' => 'hoangtrungkien@gmail.com',
                'phone' => '3218932132',
                'password' => bcrypt('123456'),
            ],
        ];

        foreach ($datas as $data) {
            User::create($data);
        }
    }
}
