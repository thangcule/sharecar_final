<?php

use Illuminate\Database\Seeder;
use App\Bookmark;

class BookmarksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $datas = [
        ];

        foreach ($datas as $data) {
            Bookmark::create($data);
        }
    }
}
