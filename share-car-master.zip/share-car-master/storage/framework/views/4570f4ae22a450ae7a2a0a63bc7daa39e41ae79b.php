	
<?php $__env->startSection('content'); ?>
<div class="container" style="background-color:white;width:70%;margin-left: 15%">
    <ul style="margin-top:20px" class="menu-ul">
        <li class="menu-li menu-li-a">
            <a href="<?php echo e(route('user.rides_offered')); ?>" class="menu-li-a" href="#ridesoffer">Rides offered</a>
        </li>
        <li class="menu-li menu-li-a menu-active">
            <a href="<?php echo e(route('user.rides_booked')); ?>"class="menu-li-a" href="#ridesbook" style="color:gray"><b>Rides booked</b></a>
        </li>
        <li class="menu-li menu-li-a">
            <a href="<?php echo e(route('user.profile')); ?>" class="menu-li-a" href="#profile">Profile</a>
        </li>
        <li class="menu-li menu-li-a">
            <a class="menu-li-a" href="#money">Money</a>
        </li>
    </ul>
    <p class="p-margin" style="font-size:24px;color:gray"><b>See all your rides booked</b></p><hr>
    <?php $__currentLoopData = $booked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bla-box" style="width:90%;height: 200px;margin-left: 5%" >
        <div class="bla-box-title col-sm-8" style="font-size: 15px;height: 65px">
        <i class="fa fa-code-fork"></i> 
        <span title="<?php echo e($book->_choose_pick_up->address); ?>"><?php echo e($book->_choose_pick_up->address); ?> </span>
        <br>
        <i class="fa fa-code-fork"></i> 
        <span title="<?php echo e($book->_choose_drop_off->address); ?>"><?php echo e($book->_choose_drop_off->address); ?> </span>
        </div>
        <div class="bla-box-title col-sm-4" style="height: 65px">
            <?php if($book->ride->status == 0): ?>
                <b>CHỦ XE ĐÃ HỦY LỘ TRÌNH</b>
            <?php else: ?> 
                <?php if($book->status == 0): ?>
                    <h1 style="font-size: 18px;color:orange">ĐANG CHỜ PHÊ DUYỆT</h1>
                <?php elseif($book->status == 1): ?>
                    <h1 style="font-size: 18px;color:green">ĐƯỢC CHẤP NHẬN</h1>
                <?php else: ?>
                    <h1 style="font-size: 18px;color:gray">BỊ TỪ CHỐI</h1>
                <?php endif; ?>
            <?php endif; ?> 
        </div>
        <div class="bla-box-title col-sm-8" style="background-color:#f1f4f6;height: 90px;margin-top:5px">
            <i class="fa fa-calendar"></i> 
            <span> <?php echo e(\App\Lib\Date::date2Text($book->_getOwner->start_date)); ?> | <?php echo e($book->_getOwner->start_time); ?>  </span><br>
            <i class="fa fa-wheelchair"></i> 
            <span><?php echo e($book['seats']); ?> x <?php echo e($book['price']); ?> đồng</span><br>
            <i class="fa fa-usd"></i> 
            <span>Total : <b><?php echo e($book['price']*$book['seats']); ?></b> đồng</span>
        </div>
        <div class="bla-box-title col-sm-4" style="background-color:#f1f4f6;height: 90px;margin-top:5px">
            <?php if($book['status'] == 0): ?>
            <p>Yêu cầu đang được phê duyệt<br>Vui lòng chờ!</p>
            <?php elseif($book['status'] == 1): ?>
                Owner phone: <?php echo e($book->user->phone); ?>

                <p>Yêu cầu của bạn đã được chấp nhận!</p>
            <?php else: ?>
            <p>Yêu cầu của bạn đã bị từ chối!<br>Thử lại sau</p>
            <?php endif; ?> 
            <button type="button" class="btn btn-link fa fa-eye">
                <a href="/ride/detail/<?php echo e($book->ride_id); ?>?choose_pick_up=<?php echo e($book->_choose_pick_up->address); ?>&choose_drop_off=<?php echo e($book->_choose_drop_off->address); ?>">
                    See ride
                </a></button>
            <form action="/user/rides_booked/delete" style="display: inline-block;" id="form<?php echo e($book->id); ?>" method="POST">    
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">    
                <button type="button" data-toggle="modal" data-target="#delete_modal" class="btn btn-link delete"  data-id="<?php echo e($book->id); ?>"><i class="fa fa-remove"> Delete</i></button>
            </form>
        </div>
        <hr>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <!-- Modal -->
    <div id="delete_modal" class="modal fade bla-modal" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Delete</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure to delete this bookmark</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancle</button>
                    <button type="button" class="btn btn-info" id="submit" data-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        var id;
        $('.delete').click(function () {
            id = $(this).data("id");
        })
        $('#submit').click(function () {
            $('#form'+id).submit();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>