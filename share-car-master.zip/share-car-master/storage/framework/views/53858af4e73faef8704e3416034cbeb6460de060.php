	
<?php $__env->startSection('content'); ?>
<div class="Layout-content">
    <div class="Home u-flex">
        <div class="HomeBlock-inner" >
            <div class="HomeBlock-media HomeBlock-media--primary HomeBlock-form" style="margin-left: 20%; width: 60%;">
            	<div class="bla-input bla-box-search">
            		<?php $length = 35; ?> 
            		<?php echo e(mb_substr($find_pick_up, 0, $length)); ?> ...&nbsp;
                    <i class="fa fa-arrow-right fa-lg"></i>		
                    &nbsp; <?php echo e(mb_substr($find_drop_off, 0, $length)); ?> ... <br>
					<span class="bla-mark"><?php echo e($find_start_date); ?></span>
                    <a href="<?php echo e(route('ride.find')); ?>" class="bla-mark pull-right" style="text-decoration: underline;">Back</a>
            	</div>
            	<?php $__currentLoopData = $filter_rides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ride): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            	<?php 
			            $pick_up = App\Location::where('id', $ride->pick_up)->first();
			            $drop_off = App\Location::where('id', $ride->drop_off)->first();
			            if (!empty($ride->stopover))
			                $stopover = App\Location::where('id', $ride->stopover)->first();
			        ?>
            	<div class="bla-box bla-ride-summary" onclick="location.href='/ride/detail/<?php echo e($ride->id); ?>?choose_pick_up=<?php echo e(rawurlencode($ride->choose_pick_up)); ?>&choose_drop_off=<?php echo e(rawurlencode($ride->choose_drop_off)); ?>'">
            		<span class="time"><?php echo e(\App\Lib\Date::date2Text($ride->start_date)); ?> <?php echo e($ride->start_time); ?></span>
					<div class="row bla-box-content" style="background: #fff">
						<div class="path col-sm-12">
	                    	<?php echo e(mb_substr($pick_up->address, 0, $length)); ?> ...&nbsp;
	                        <i class="fa fa-arrow-right fa-lg"></i>		
	                        &nbsp; <?php echo e(mb_substr($drop_off->address, 0, $length)); ?> ...
	                        <div class="bla-ride-owner">
	                        	<img src="/images/users/default.png" alt="">
	                        	<?php echo e($ride->user->name); ?>

	                        	<span class="money"><?php echo e($ride->path); ?> đ</span>
	                        </div>
    					  	<?php if(!empty($stopover)): ?>
    	                    	<span class="bla-mark">Stop-over: </span>
	                        	<span style="font-weight: normal;"><?php echo e($stopover->address); ?></span>
            	            <?php endif; ?>
	                    </div>
					</div>
            	</div>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>