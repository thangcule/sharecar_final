	
<?php $__env->startSection('content'); ?>
<div class="container" style="background-color:white;width:70%;margin-left: 15%">
    <ul style="margin-top:20px" class="menu-ul">
        <li class="menu-li menu-li-a menu-active">
            <a href="<?php echo e(route('user.rides_offered')); ?>" class="menu-li-a" href="#ridesoffer" style="color:gray"><b>Rides offered</b></a>
        </li>
        <li class="menu-li menu-li-a">
            <a href="<?php echo e(route('user.rides_booked')); ?>" class="menu-li-a" href="#ridesbook">Rides booked</a>
        </li>
        <li class="menu-li menu-li-a">
            <a href="<?php echo e(route('user.profile')); ?>" class="menu-li-a" href="#profile">Profile</a>
        </li>
        <li class="menu-li menu-li-a">
            <a class="menu-li-a" href="#money">Money</a>
        </li>
    </ul>
    <p class="p-margin"><b>See all your upcoming rides</b></p>
    <div class="bla-box col-sm-10" style="margin-left: 5%">
        <?php $__currentLoopData = $ride; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
            $pick_up = App\Location::where('id', $r->pick_up)->first();
            $drop_off = App\Location::where('id', $r->drop_off)->first();
            if (!empty($r->stopover))
                $stopover = App\Location::where('id', $r->stopover)->first();
        ?>
        <?php if ($r->status == 0) continue; ?>
        <h3 class="bla-box-title">
            <i class="fa fa-code-fork"></i>
            <span title="<?php echo e($pick_up->address); ?>"><?php echo e($pick_up->address); ?></span><br>
            <i class="fa fa-code-fork"></i>
            <span title="<?php echo e($drop_off->address); ?>"><?php echo e($drop_off->address); ?></span>
        </h3>
		<div class="bla-box-content" style="font-size: 13px">
            <div class="bla-margin20">
                <i class="fa fa-calendar fa-lg"></i> 
                <span><?php echo e(\App\Lib\Date::date2Text($r['start_date'])); ?> | <?php echo e($r['start_time']); ?></span>
            </div><hr>
            <div class="bla-margin20">
                <i class="fa fa-circle-o fa-lg"></i> 
                <span>Ride summary<br>
                <i class="fa fa-code-fork"> Pick up : </i> 
                <span title="<?php echo e($pick_up->address); ?>"><?php echo e($pick_up->address); ?></span><br>
                <?php if(!empty($stopover)): ?>
                <i class="fa fa-code-fork"> Stopover : </i> 
                <span title="<?php echo e($stopover->address); ?>"><?php echo e($stopover->address); ?></span><br>
                <?php endif; ?>
                <i class="fa fa-code-fork"> Drop off : </i>
                <span title="<?php echo e($drop_off->address); ?>"><?php echo e($drop_off->address); ?></span></span>
            </div>
            <div class="bla-margin20">
                <div class="col-sm-4">
                    <span><i class="fa fa-wheelchair"></i> : <?php echo e($r['seats']); ?> seat</span><br>
                    <span><i class="fa fa-usd"></i> : <?php echo e($r['path']); ?> VND / người</span>
                </div>
                <div class="col-sm-7">
                    <div class="btn-group">
                        <a type="button" class="btn btn-link" href="/ride/schedule_edit?ride_id=<?php echo e($r->id); ?>"><i class="fa fa-edit"></i> Edit</a>
                        <a type="button" class="btn btn-link" href="/ride/<?php echo e($r->id); ?>/passengers"><i class=" fa fa-eye"></i> See passengers</a>
                        <form action="/user/rides_offered/delete" style="display: inline-block" id="form<?php echo e($r->id); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="ride_id" value="<?php echo e($r->id); ?>">    
                            <button type="button" data-toggle="modal" data-target="#delete_modal" class="btn btn-link delete"  data-id="<?php echo e($r->id); ?>"><i class="fa fa-remove"> Delete</i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <br><hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
    <!-- Modal -->
    <div id="delete_modal" class="modal fade bla-modal" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Delete</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure to delete this bookmark</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancle</button>
                    <button type="button" class="btn btn-info" id="submit" data-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        var id;
        $('.delete').click(function () {
            id = $(this).data("id");
        })
        $('#submit').click(function () {
            $('#form'+id).submit();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>