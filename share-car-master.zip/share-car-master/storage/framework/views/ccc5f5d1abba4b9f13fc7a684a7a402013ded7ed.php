<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <title>Homepage</title>
    <meta name="viewport" content="initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
    <link rel="stylesheet" href="<?php echo e(asset('common/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('common/bootstrap/css/bootstrap-datetimepicker.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/blablacar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php echo $__env->yieldContent('link'); ?>
    <?php echo $__env->yieldContent('style'); ?>
    <script src="<?php echo e(asset('common/bootstrap/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('common/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('common/bootstrap/js/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('common/bootstrap/js/bootstrap-datetimepicker.min.js')); ?>"></script>
 
</head>
<body>
    <div class="Layout">
        <div class="Layout-header">
            <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <main id="main-container" class="Layout-main " role="main" style="margin-top: -55px;">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
        <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>