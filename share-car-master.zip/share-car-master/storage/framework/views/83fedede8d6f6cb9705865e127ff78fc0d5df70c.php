	
<?php $__env->startSection('content'); ?>
<div class="container" style="background-color:white;width:70%">
    <ul style="margin-top:20px" class="menu-ul">
        <li class="menu-li menu-li-a">
            <a href="<?php echo e(route('user.rides_offered')); ?>" class="menu-li-a" href="#ridesoffer">Rides offered</a>
        </li>
        <li class="menu-li menu-li-a">
            <a href="<?php echo e(route('user.rides_booked')); ?>" class="menu-li-a" href="#ridesbook">Rides booked</a>
        </li>
        <li class="menu-li menu-li-a menu-active">
            <a href="<?php echo e(route('user.profile')); ?>" class="menu-li-a" href="#profile" style="color:gray"><b>Profile</b></a>
        </li>
        <li class="menu-li menu-li-a">
            <a class="menu-li-a" href="#money">Money</a>
        </li>
    </ul>
    <div class="Layout-content">
        <div class="Home u-flex">
            <div class="HomeBlock-inner" >
                <div style="margin-left: 18%; width: 60%">
                    <h2 style="text-align:center;color:gray">Your personal information</h2><hr>
                    
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('user.profile')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <input id="name" type="text" class="bla-input" name="name" value="<?php echo e(empty(old('name')) ? $user->name : old('name')); ?>" autofocus placeholder="Name">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                            <input id="phone" type="text" class="bla-input" name="phone" value="<?php echo e(empty(old('phone')) ? $user->phone : old('phone')); ?>"  autofocus placeholder="Phone">
                            <?php if($errors->has('phone')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('phone')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">          
                            <button class="bla-btn" type="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>